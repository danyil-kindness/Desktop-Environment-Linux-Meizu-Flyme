#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# Удаление Flyme Shell. Xfce не затрагивается.
#
# Использование:
#   ./uninstall.sh            — удалить компоненты, темы и сеанс
#   ./uninstall.sh --purge    — additionally удалить ~/.config/flyme-shell

set -euo pipefail

PURGE=0
[ "${1:-}" = "--purge" ] && PURGE=1

if [ "$(id -u)" -ne 0 ]; then
    exec sudo bash "$0" "$@"
fi

BIN_DST="/usr/local/bin"
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)
REAL_UID=$(id -u "$REAL_USER")

echo "== Удаление Flyme Shell =="

# горячие клавиши пользователя
if command -v xfconf-query >/dev/null 2>&1 && [ "$REAL_USER" != root ]; then
    run_as_user() {
        sudo -u "$REAL_USER" env HOME="$REAL_HOME" \
            XDG_RUNTIME_DIR="/run/user/${REAL_UID}" \
            DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${REAL_UID}/bus" \
            "$@" >/dev/null 2>&1 || true
    }
    for n in flyme-launcher flyme-control flyme-lock \
             flyme-vol-up flyme-vol-down flyme-mute; do
        run_as_user xfconf-query -c xfce4-keyboard-shortcuts -r -p "/global/custom/${n}/name"
        run_as_user xfconf-query -c xfce4-keyboard-shortcuts -r -p "/global/custom/${n}/binding"
        run_as_user xfconf-query -c xfce4-keyboard-shortcuts -r -p "/commands/custom/${n}"
    done
    rm -f "/run/user/${REAL_UID}/flyme-shell.lock"
fi

rm -rf /usr/share/flyme-shell
rm -rf /usr/share/themes/flyme-gtk /usr/share/themes/flyme-gtk-dark
rm -rf /usr/share/themes/flyme-light /usr/share/themes/flyme-dark
rm -rf /usr/share/backgrounds/flyme
rm -f /usr/share/xsessions/meizu-flyme.desktop

for n in panel dock launcher control-center lock notifications; do
    rm -f "${BIN_DST}/flyme-${n}"
done

# восстановляем прошлый flyme-session, если он был сохранён
latest_bak=$(ls -1t "${BIN_DST}"/flyme-session.bak.* 2>/dev/null | head -1 || true)
if [ -n "$latest_bak" ]; then
    mv "$latest_bak" "${BIN_DST}/flyme-session"
    echo "Восстановлен прежний flyme-session: $latest_bak"
else
    rm -f "${BIN_DST}/flyme-session"
fi

if [ "$PURGE" -eq 1 ]; then
    rm -rf "${REAL_HOME}/.config/flyme-shell"
    echo "Удалена конфигурация ${REAL_HOME}/.config/flyme-shell"
fi

echo "Готово. Пакеты Xfce не тронуты."
