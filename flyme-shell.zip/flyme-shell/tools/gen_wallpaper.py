#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация заставок Flyme (оригинальная градиентная графика).

Использование: gen_wallpaper.py [--dest /usr/share/backgrounds/flyme] [--size 1920x1080]
"""

import argparse
import math
import os
import random
import sys

import cairo


def _blob(cr, cx, cy, radius, rgba):
    grad = cairo.RadialGradient(cx, cy, 0, cx, cy, radius)
    grad.add_color_stop_rgba(0.0, *rgba)
    grad.add_color_stop_rgba(1.0, rgba[0], rgba[1], rgba[2], 0.0)
    cr.set_source(grad)
    cr.paint()


def dark_wallpaper(w, h):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(surf)

    grad = cairo.LinearGradient(0, 0, w * 0.3, h)
    grad.add_color_stop_rgb(0.0, 0.055, 0.105, 0.180)   # глубокий синий
    grad.add_color_stop_rgb(0.55, 0.030, 0.055, 0.105)
    grad.add_color_stop_rgb(1.0, 0.015, 0.025, 0.050)
    cr.set_source(grad)
    cr.paint()

    _blob(cr, w * 0.78, h * 0.24, w * 0.42, (0.0, 0.53, 1.0, 0.34))   # синее свечение
    _blob(cr, w * 0.20, h * 0.82, w * 0.34, (0.0, 0.35, 0.80, 0.22))
    _blob(cr, w * 0.92, h * 0.88, w * 0.26, (0.10, 0.75, 0.85, 0.12))

    # мягкая «волна»
    cr.set_source_rgba(1, 1, 1, 0.045)
    cr.move_to(0, h * 0.66)
    for x in range(0, w + 20, 20):
        y = h * 0.66 + math.sin(x / 220.0) * h * 0.05 \
            + math.sin(x / 90.0) * h * 0.012
        cr.line_to(x, y)
    cr.line_to(w, h)
    cr.line_to(0, h)
    cr.close_path()
    cr.fill()

    # тонкие «звёзды» (псевдослучайно, детерминированно)
    rng = random.Random(7)
    cr.set_source_rgba(1, 1, 1, 0.30)
    for _i in range(90):
        x = rng.uniform(0, w)
        y = rng.uniform(0, h * 0.55)
        r = rng.uniform(0.5, 1.5)
        cr.set_source_rgba(1, 1, 1, rng.uniform(0.12, 0.4))
        cr.arc(x, y, r, 0, 2 * math.pi)
        cr.fill()
    return surf


def light_wallpaper(w, h):
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    cr = cairo.Context(surf)

    grad = cairo.LinearGradient(0, 0, w * 0.2, h)
    grad.add_color_stop_rgb(0.0, 0.878, 0.925, 0.980)
    grad.add_color_stop_rgb(0.6, 0.945, 0.965, 0.985)
    grad.add_color_stop_rgb(1.0, 0.995, 0.997, 1.0)
    cr.set_source(grad)
    cr.paint()

    _blob(cr, w * 0.80, h * 0.20, w * 0.45, (0.0, 0.53, 1.0, 0.16))
    _blob(cr, w * 0.15, h * 0.85, w * 0.38, (0.35, 0.65, 1.0, 0.14))
    _blob(cr, w * 0.55, h * 0.55, w * 0.30, (1.0, 1.0, 1.0, 0.55))

    cr.set_source_rgba(0.0, 0.53, 1.0, 0.05)
    cr.move_to(0, h * 0.72)
    for x in range(0, w + 20, 20):
        y = h * 0.72 + math.sin(x / 260.0) * h * 0.045
        cr.line_to(x, y)
    cr.line_to(w, h)
    cr.line_to(0, h)
    cr.close_path()
    cr.fill()
    return surf


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default="/usr/share/backgrounds/flyme")
    ap.add_argument("--size", default="1920x1080")
    args = ap.parse_args()

    try:
        w, h = (int(v) for v in args.size.lower().split("x"))
    except Exception:
        sys.stderr.write("Неверный размер: %s\n" % args.size)
        return 1

    os.makedirs(args.dest, exist_ok=True)
    for name, fn in (("flyme-dark.png", dark_wallpaper),
                     ("flyme-light.png", light_wallpaper)):
        path = os.path.join(args.dest, name)
        fn(w, h).write_to_png(path)
        print("Заставка: %s" % path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
