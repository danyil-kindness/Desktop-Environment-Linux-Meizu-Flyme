#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация темы окон xfwm4 «flyme» (заголовки и кнопки в стиле Flyme).

Использование: gen_xfwm4.py --variant light|dark --dest /usr/share/themes/flyme-light
"""

import argparse
import math
import os
import sys

import cairo

TITLE_H = 36
BORDER = 2
CORNER_W = 8          # ширина верхних уголков
BOTTOM_CORNER = 10    # размер нижних уголков
BTN_W, BTN_H = 28, 36

THEMES = {
    "light": dict(
        title=(1.0, 1.0, 1.0),
        title_inactive=(0.968, 0.972, 0.980),
        border=(0.866, 0.886, 0.913),
        text=(0.106, 0.114, 0.129),
        text_inactive=(0.65, 0.68, 0.72),
        hover=(0.0, 0.0, 0.0, 0.07),
        pressed=(0.0, 0.0, 0.0, 0.14),
        close_hover=(1.0, 0.373, 0.341, 1.0),
        close_pressed=(0.878, 0.282, 0.243, 1.0),
    ),
    "dark": dict(
        title=(0.137, 0.149, 0.168),
        title_inactive=(0.114, 0.125, 0.141),
        border=(0.180, 0.196, 0.220),
        text=(0.929, 0.937, 0.949),
        text_inactive=(0.48, 0.51, 0.56),
        hover=(1.0, 1.0, 1.0, 0.10),
        pressed=(1.0, 1.0, 1.0, 0.18),
        close_hover=(1.0, 0.271, 0.227, 1.0),
        close_pressed=(0.847, 0.212, 0.180, 1.0),
    ),
}

THEMERC = """active_text_color={text}
inactive_text_color={text_inactive}
title_shadow_active=false
title_shadow_inactive=false
full_width_title=true
title_vertical_offset_active=0
title_vertical_offset_inactive=0
button_offset=2
button_spacing=0
show_app_icon=false
show_popup_shadow=true
shadow_delta_width=0
shadow_delta_height=4
shadow_delta_x=0
shadow_delta_y=-8
shadow_opacity=40
"""


def rgba(c):
    return c if len(c) == 4 else (c[0], c[1], c[2], 1.0)


def new_surface(w, h):
    return cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)


def solid(w, h, color):
    surf = new_surface(w, h)
    cr = cairo.Context(surf)
    cr.set_source_rgba(*rgba(color))
    cr.rectangle(0, 0, w, h)
    cr.fill()
    return surf


def top_corner(w, h, color, radius=7, mirror=False):
    surf = new_surface(w, h)
    cr = cairo.Context(surf)
    if mirror:
        cr.translate(w, 0)
        cr.scale(-1, 1)
    r = radius
    cr.new_path()
    cr.move_to(w, h)
    cr.line_to(w, 0)
    cr.line_to(r, 0)
    cr.arc_negative(r, r, r, -math.pi / 2, math.pi)
    cr.line_to(0, h)
    cr.close_path()
    cr.set_source_rgba(*rgba(color))
    cr.fill()
    return surf


def bottom_corner(w, h, color, radius=7, mirror=False):
    surf = new_surface(w, h)
    cr = cairo.Context(surf)
    if mirror:
        cr.translate(w, 0)
        cr.scale(-1, 1)
    r = radius
    cr.new_path()
    cr.move_to(w, 0)
    cr.line_to(w, h)
    cr.line_to(r, h)
    cr.arc(r, h - r, r, math.pi / 2, math.pi)
    cr.line_to(0, 0)
    cr.close_path()
    cr.set_source_rgba(*rgba(color))
    cr.fill()
    return surf


def _glyph(cr, kind, cx, cy, color, size=10.0):
    cr.set_source_rgba(*rgba(color))
    cr.set_line_width(1.7)
    cr.set_line_cap(cairo.LINE_CAP_ROUND)
    half = size / 2.0
    if kind == "close":
        cr.move_to(cx - half, cy - half)
        cr.line_to(cx + half, cy + half)
        cr.move_to(cx + half, cy - half)
        cr.line_to(cx - half, cy + half)
        cr.stroke()
    elif kind == "hide":
        cr.move_to(cx - half, cy)
        cr.line_to(cx + half, cy)
        cr.stroke()
    elif kind in ("maximize", "maximize-toggled"):
        cr.set_line_width(1.5)
        if kind == "maximize":
            cr.rectangle(cx - half + 1, cy - half + 1, size - 2, size - 2)
        else:
            cr.rectangle(cx - half + 1, cy - half + 3, size - 5, size - 5)
            cr.move_to(cx + half - 4, cy - half + 1)
            cr.line_to(cx + half - 1, cy - half + 1)
            cr.line_to(cx + half - 1, cy + half - 4)
        cr.stroke()
    elif kind == "restore":
        cr.set_line_width(1.5)
        cr.rectangle(cx - half + 1, cy - half + 3, size - 5, size - 5)
        cr.stroke()
        cr.rectangle(cx - half + 3, cy - half + 1, size - 5, size - 5)
        cr.stroke()
    elif kind == "menu":
        for dy in (-3.5, 0, 3.5):
            cr.move_to(cx - half, cy + dy)
            cr.line_to(cx + half, cy + dy)
        cr.stroke()
    elif kind in ("shade", "shade-toggled"):
        cr.move_to(cx - half, cy + 2)
        cr.line_to(cx, cy - 3)
        cr.line_to(cx + half, cy + 2)
        cr.stroke()
    elif kind in ("stick", "stick-toggled"):
        cr.move_to(cx, cy - half)
        cr.line_to(cx, cy + half)
        cr.move_to(cx - half, cy)
        cr.line_to(cx + half, cy)
        cr.stroke()


def flatten(surf, bg):
    """Наложить рисунок на непрозрачный фон заголовка.

    xfwm4 4.18 рисует из кнопочных PNG только полностью непрозрачные пиксели,
    поэтому полупрозрачные (сглаженные) края иначе просто исчезают.
    """
    out_surf = new_surface(surf.get_width(), surf.get_height())
    out = cairo.Context(out_surf)
    out.set_source_rgba(*rgba(bg))
    out.paint()
    out.set_source_surface(surf, 0, 0)
    out.paint()
    return out_surf


def button(kind, state, pal):
    surf = new_surface(BTN_W, BTN_H)
    cr = cairo.Context(surf)
    cx, cy, r = BTN_W / 2.0, BTN_H / 2.0, 11.0

    bg = None
    glyph = pal["text"]
    if state == "inactive":
        glyph = pal["text_inactive"]
    elif state == "prelight":
        bg = pal["close_hover"] if kind == "close" else pal["hover"]
        glyph = (1, 1, 1) if kind == "close" else pal["text"]
    elif state == "pressed":
        bg = pal["close_pressed"] if kind == "close" else pal["pressed"]
        glyph = (1, 1, 1) if kind == "close" else pal["text"]

    if bg is not None:
        cr.set_source_rgba(*rgba(bg))
        cr.arc(cx, cy, r, 0, 2 * math.pi)
        cr.fill()

    _glyph(cr, kind, cx, cy, glyph)
    base = pal["title_inactive"] if state == "inactive" else pal["title"]
    return flatten(surf, base)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variant", choices=("light", "dark"), default="light")
    ap.add_argument("--dest", required=True)
    args = ap.parse_args()

    pal = THEMES[args.variant]
    out = os.path.join(args.dest, "xfwm4")
    os.makedirs(out, exist_ok=True)

    def save(surf, name):
        surf.write_to_png(os.path.join(out, name))

    # заголовок (тянется по ширине)
    t1 = solid(BORDER, TITLE_H, pal["title"])
    save(t1, "title-1-active.png")
    save(solid(BORDER, TITLE_H, pal["title_inactive"]), "title-1-inactive.png")
    for i in (2, 3, 4, 5):
        for st in ("active", "inactive"):
            src = os.path.join(out, "title-1-%s.png" % st)
            dst = os.path.join(out, "title-%d-%s.png" % (i, st))
            if os.path.lexists(dst):
                os.remove(dst)
            os.symlink(os.path.basename(src), dst)

    # верхние уголки
    save(top_corner(CORNER_W, TITLE_H, pal["title"]), "top-left-active.png")
    save(top_corner(CORNER_W, TITLE_H, pal["title_inactive"]), "top-left-inactive.png")
    save(top_corner(CORNER_W, TITLE_H, pal["title"], mirror=True), "top-right-active.png")
    save(top_corner(CORNER_W, TITLE_H, pal["title_inactive"], mirror=True),
         "top-right-inactive.png")

    # бока и низ
    save(solid(BORDER, TITLE_H, pal["border"]), "left-active.png")
    save(solid(BORDER, TITLE_H, pal["border"]), "left-inactive.png")
    save(solid(BORDER, TITLE_H, pal["border"]), "right-active.png")
    save(solid(BORDER, TITLE_H, pal["border"]), "right-inactive.png")
    save(solid(16, BORDER, pal["border"]), "bottom-active.png")
    save(solid(16, BORDER, pal["border"]), "bottom-inactive.png")
    bc = BOTTOM_CORNER
    save(bottom_corner(bc, bc, pal["border"]), "bottom-left-active.png")
    save(bottom_corner(bc, bc, pal["border"]), "bottom-left-inactive.png")
    save(bottom_corner(bc, bc, pal["border"], mirror=True), "bottom-right-active.png")
    save(bottom_corner(bc, bc, pal["border"], mirror=True), "bottom-right-inactive.png")

    # кнопки
    for kind in ("close", "hide", "maximize", "maximize-toggled", "menu",
                 "restore", "shade", "shade-toggled", "stick", "stick-toggled"):
        for state in ("active", "inactive", "prelight", "pressed"):
            save(button(kind, state, pal), "%s-%s.png" % (kind, state))

    with open(os.path.join(out, "themerc"), "w", encoding="utf-8") as fh:
        fh.write(THEMERC.format(
            text="#%02X%02X%02X" % tuple(round(c * 255) for c in pal["text"][:3]),
            text_inactive="#%02X%02X%02X" %
            tuple(round(c * 255) for c in pal["text_inactive"][:3]),
        ))

    print("Тема xfwm4 (%s) создана: %s" % (args.variant, out))
    return 0


if __name__ == "__main__":
    sys.exit(main())
