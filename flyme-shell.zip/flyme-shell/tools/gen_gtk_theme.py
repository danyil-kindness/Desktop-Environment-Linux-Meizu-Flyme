#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генерация GTK-тем flyme-gtk (светлая) и flyme-gtk-dark из шаблона.

Использование: gen_gtk_theme.py [--dest /usr/share/themes]
"""

import argparse
import os
import sys

PALETTES = {
    "light": dict(
        BG="#F4F6F8", SURFACE="#FFFFFF", SURFACE2="#EEF1F5",
        TEXT="#17191C", SUB="#8B93A1", ACCENT="#0088FF", ACCENT_TEXT="#FFFFFF",
        BORDER="#E3E7ED", DANGER="#FF3B30", SUCCESS="#34C759",
    ),
    "dark": dict(
        BG="#16181C", SURFACE="#23262B", SURFACE2="#2A2E34",
        TEXT="#F2F3F5", SUB="#9AA1AC", ACCENT="#0088FF", ACCENT_TEXT="#FFFFFF",
        BORDER="#2E3238", DANGER="#FF453A", SUCCESS="#30D158",
    ),
}

INDEX_TMPL = """[Desktop Entry]
Type=X-GNOME-Metatheme
Name={name}
Comment=Meizu Flyme inspired theme
GtkTheme={gtk}
IconTheme={icons}
CursorTheme=Bibata-Modern-Ice
ButtonLayout=close,minimize,maximize
"""


def build(tpl, mode):
    css = tpl
    for key, val in PALETTES[mode].items():
        css = css.replace("{{%s}}" % key, val)
    return css


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dest", default="/usr/share/themes")
    ap.add_argument("--template", default=None,
                    help="путь к gtk.css.tpl (автоопределение)")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    repo_themes = os.path.join(os.path.dirname(here), "themes")
    tpl_path = args.template or os.path.join(repo_themes, "gtk.css.tpl")
    if not os.path.isfile(tpl_path):
        sys.stderr.write("Не найден шаблон: %s\n" % tpl_path)
        return 1
    with open(tpl_path, encoding="utf-8") as fh:
        tpl = fh.read()

    for mode, (theme_name, gtk_name, icons) in {
        "light": ("flyme-gtk", "flyme-gtk", "Papirus"),
        "dark": ("flyme-gtk-dark", "flyme-gtk-dark", "Papirus-Dark"),
    }.items():
        css = build(tpl, mode)
        base = os.path.join(args.dest, theme_name)
        for sub in ("gtk-3.0", "gtk-4.0"):
            d = os.path.join(base, sub)
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, "gtk.css"), "w", encoding="utf-8") as fh:
                fh.write(css)
        with open(os.path.join(base, "index.theme"), "w", encoding="utf-8") as fh:
            fh.write(INDEX_TMPL.format(
                name="Flyme (%s)" % ("тёмная" if mode == "dark" else "светлая"),
                gtk=gtk_name, icons=icons,
            ))
        print("GTK-тема создана: %s" % base)
    return 0


if __name__ == "__main__":
    sys.exit(main())
