#!/usr/bin/env bash
# -*- coding: utf-8 -*-
# Установка оболочки Meizu Flyme Shell для Linux Mint (Xfce).
#
# Использование:
#   ./install.sh              — установка компонентов (запросит sudo)
#   ./install.sh --default    — additionally сделать Flyme сеансом по умолчанию
#   ./install.sh --no-deps    — не проверять/не ставить пакеты зависимостей
#
# Существующий Xfce НЕ удаляется: Flyme появится отдельным сеансом в менеджере
# входа, XFCE остаётся нетронутым.

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SHARE_DST="/usr/share/flyme-shell"
BIN_DST="/usr/local/bin"
THEMES_DST="/usr/share/themes"
BG_DST="/usr/share/backgrounds/flyme"
SESSION_DST="/usr/share/xsessions"

WITH_DEPS=1
SET_DEFAULT=0
for arg in "$@"; do
    case "$arg" in
        --default) SET_DEFAULT=1 ;;
        --no-deps) WITH_DEPS=0 ;;
        -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
        *) echo "Неизвестный параметр: $arg" >&2; exit 1 ;;
    esac
done

if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
        echo "Для установки в систему нужны права sudo."
        exec sudo bash "$0" "$@"
    fi
    echo "Запустите от root или установите sudo." >&2
    exit 1
fi

# пользователь, запустивший sudo (для настройки его xfconf-ключей)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)

echo "== Проверка зависимостей =="

# Проверяем по фактическим командам/модулям, ставим по именам пакетов apt
MISSING_REQ=()
py_ok() { python3 -c "$1" >/dev/null 2>&1; }
add_if_missing() {           # команда пакет
    command -v "$1" >/dev/null 2>&1 || MISSING_REQ+=("$2")
}

command -v python3 >/dev/null 2>&1 || MISSING_REQ+=("python3")
py_ok "import gi" || MISSING_REQ+=("python3-gi")
py_ok "import cairo" || MISSING_REQ+=("python3-cairo")
py_ok "import dbus" || MISSING_REQ+=("python3-dbus")
py_ok "import gi; gi.require_version('Gtk','3.0'); from gi.repository import Gtk" \
    || MISSING_REQ+=("gir1.2-gtk-3.0")
py_ok "import gi; gi.require_version('Wnck','3.0'); from gi.repository import Wnck" \
    || MISSING_REQ+=("gir1.2-wnck-3.0")
add_if_missing xfwm4 xfwm4
add_if_missing xfsettingsd xfce4-settings
add_if_missing xfconf-query xfconf

if [ "${#MISSING_REQ[@]}" -gt 0 ]; then
    echo "Отсутствуют обязательные пакеты: ${MISSING_REQ[*]}"
    if [ "$WITH_DEPS" -eq 1 ] && command -v apt-get >/dev/null 2>&1; then
        read -r -p "Установить их через apt-get? [Д/н] " ans
        if [[ -z "$ans" || "$ans" =~ ^[ДдDdYy] ]]; then
            apt-get update -qq || true
            if ! DEBIAN_FRONTEND=noninteractive apt-get install -y "${MISSING_REQ[@]}"; then
                echo "Не удалось установить: ${MISSING_REQ[*]}" >&2
                echo "Установите их вручную и перезапустите установку." >&2
                exit 1
            fi
        else
            echo "Продолжаю без них — оболочка может не работать." >&2
        fi
    else
        echo "Установите их вручную и перезапустите установку." >&2
        exit 1
    fi
fi

MISSING_OPT=()
add_opt() {                  # команда пакет
    command -v "$1" >/dev/null 2>&1 || MISSING_OPT+=("$2")
}
add_opt xfdesktop xfdesktop4
add_opt xfce4-session xfce4-session
add_opt nmcli network-manager
add_opt bluetoothctl bluez
add_opt brightnessctl brightnessctl
[ -d /usr/share/icons/Papirus ] || MISSING_OPT+=("papirus-icon-theme")
add_opt light-locker light-locker
add_opt xfce4-power-manager xfce4-power-manager
if [ "${#MISSING_OPT[@]}" -gt 0 ]; then
    echo "Рекомендуемые пакеты отсутствуют (работать будет, но лучше поставить):"
    echo "  ${MISSING_OPT[*]}"
fi

echo "== Установка файлов =="

install -d "$SHARE_DST" "$BIN_DST" "$THEMES_DST" "$BG_DST" "$SESSION_DST"

# 1. Python-пакет оболочки
rm -rf "${SHARE_DST}/flyme_shell"
cp -r "$ROOT_DIR/share/flyme_shell" "$SHARE_DST/flyme_shell"
chmod -R a+rX "$SHARE_DST"

# 2. Команды
for f in "$ROOT_DIR"/bin/flyme-*; do
    install -m 0755 "$f" "$BIN_DST/$(basename "$f")"
done

# 3. Скрипт сеанса (с бэкапом прошлой версии)
if [ -f "$BIN_DST/flyme-session" ] && ! grep -q "Сеанс «Meizu Flyme OS»" "$BIN_DST/flyme-session" 2>/dev/null; then
    cp -a "$BIN_DST/flyme-session" "$BIN_DST/flyme-session.bak.$(date +%Y%m%d%H%M%S)"
    echo "  прежний flyme-session сохранён как *.bak"
fi
install -m 0755 "$ROOT_DIR/session/flyme-session" "$BIN_DST/flyme-session"

# 4. Сеанс входа (перезаписываем прошлую запись kiosk-версии)
install -m 0644 "$ROOT_DIR/session/flyme.desktop" "$SESSION_DST/meizu-flyme.desktop"

# 5. Темы GTK
python3 "$ROOT_DIR/tools/gen_gtk_theme.py" --dest "$THEMES_DST"

# 6. Темы окон xfwm4 (с откатом на Mint-Y при сбое генерации)
for variant in light dark; do
    tdir="${THEMES_DST}/flyme-${variant}"
    if ! python3 "$ROOT_DIR/tools/gen_xfwm4.py" --variant "$variant" --dest "$tdir"; then
        echo "  генерация xfwm4 (${variant}) не удалась — копирую Mint-Y как основу"
        base="Mint-Y"
        [ "$variant" = dark ] && base="Mint-Y-Dark"
        rm -rf "${tdir}/xfwm4"
        cp -r "/usr/share/themes/${base}/xfwm4" "${tdir}/xfwm4"
        [ -f "${THEMES_DST}/flyme-gtk/index.theme" ] || true
    fi
    chmod -R a+rX "$tdir"
done

# 7. Заставки
python3 "$ROOT_DIR/tools/gen_wallpaper.py" --dest "$BG_DST"

# 8. Горячие клавиши (глобальные — работают и в Xfce, команды только наши)
echo "== Горячие клавиши =="
as_user() {
    local u="$1"; shift
    local uid
    uid=$(id -u "$u")
    if [ "$(id -u)" -eq 0 ] && [ "$u" != root ]; then
        # sudo сбрасывает окружение — восстанавливаем D-Bus и X сессии пользователя
        sudo -u "$u" env HOME="$REAL_HOME" \
            DISPLAY="${DISPLAY:-:0}" \
            XDG_RUNTIME_DIR="/run/user/${uid}" \
            DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/${uid}/bus" \
            "$@"
    else
        "$@"
    fi
}

set_shortcut() {   # имя клавиша команда подпись
    local name="$1" key="$2" cmd="$3" label="$4"
    if ! command -v xfconf-query >/dev/null 2>&1; then return 0; fi
    as_user "$REAL_USER" xfconf-query -c xfce4-keyboard-shortcuts \
        -p "/global/custom/${name}/name" -n -t string -s "$label" >/dev/null 2>&1 || true
    as_user "$REAL_USER" xfconf-query -c xfce4-keyboard-shortcuts \
        -p "/global/custom/${name}/binding" -n -t string -s "$key" >/dev/null 2>&1 || true
    as_user "$REAL_USER" xfconf-query -c xfce4-keyboard-shortcuts \
        -p "/commands/custom/${name}" -n -t string -s "$cmd" >/dev/null 2>&1 || true
    echo "  ${key} → ${cmd}"
}

set_shortcut "flyme-launcher"    "<Super>space" "flyme-launcher"    "Flyme: лаунчер"
set_shortcut "flyme-control"     "<Super>a"     "flyme-control-center" "Flyme: центр управления"
set_shortcut "flyme-lock"        "<Super>l"     "flyme-lock"        "Flyme: блокировка"

# мультимедийные клавиши ноутбука
set_shortcut "flyme-vol-up"   "<XF86AudioRaiseVolume>" \
    "pactl set-sink-volume @DEFAULT_SINK@ +5%" "Громкость +"
set_shortcut "flyme-vol-down" "<XF86AudioLowerVolume>" \
    "pactl set-sink-volume @DEFAULT_SINK@ -5%" "Громкость −"
set_shortcut "flyme-mute"     "<XF86AudioMute>" \
    "pactl set-sink-mute @DEFAULT_SINK@ toggle" "Выключить звук"

# 9. Сеанс по умолчанию (по желанию)
if [ "$SET_DEFAULT" -eq 1 ]; then
    echo "== Сеанс Flyme по умолчанию =="
    LM_CONF="/etc/lightdm/lightdm.conf"
    if [ -f "$LM_CONF" ]; then
        cp -a "$LM_CONF" "${LM_CONF}.bak.$(date +%Y%m%d%H%M%S)"
        if grep -qE '^\s*user-session=' "$LM_CONF"; then
            sed -i -E "s|^\s*user-session=.*|user-session=meizu-flyme|" "$LM_CONF"
        else
            printf '\n[Seat:*]\nuser-session=meizu-flyme\n' >> "$LM_CONF"
        fi
        echo "  LightDM: user-session=meizu-flyme"
    else
        echo "  $LM_CONF не найден — пропущено."
    fi
fi

echo
echo "== Установка завершена =="
echo "1. Выйдите из текущего сеанса (или перезагрузитесь)."
echo "2. На экране входа выберите сеанс «Meizu Flyme OS»."
echo "3. XFCE осталось нетронутым — переключайтесь между сеансами как обычно."
echo
echo "Горячие клавиши: Super+Пробел — лаунчер, Super+A — центр управления,"
echo "Super+L — блокировка. Настройки: ~/.config/flyme-shell/config.ini"
