/* ============================================================
   Flyme GTK theme — светлая/тёмная тема в духе Meizu Flyme 9/10
   Файл генерируется tools/gen_gtk_theme.py из этого шаблона.
   ============================================================ */

@define-color bg {{BG}};
@define-color surface {{SURFACE}};
@define-color surface2 {{SURFACE2}};
@define-color text {{TEXT}};
@define-color sub {{SUB}};
@define-color accent {{ACCENT}};
@define-color accent_text {{ACCENT_TEXT}};
@define-color border {{BORDER}};
@define-color danger {{DANGER}};
@define-color success {{SUCCESS}};

* {
    font-family: "Noto Sans", "Cantarell", "DejaVu Sans", sans-serif;
}

window, .background {
    background-color: @bg;
    color: @text;
}

/* ------------------------------------------------------- заголовки окон */

headerbar,
.titlebar {
    background-color: @surface;
    color: @text;
    border: none;
    box-shadow: none;
    padding: 4px;
    min-height: 32px;
}

headerbar .title,
.titlebar .title {
    font-weight: bold;
    font-size: 13px;
}

/* ------------------------------------------------------------- кнопки */

button {
    background-image: none;
    background-color: @surface2;
    border: 1px solid @border;
    border-radius: 8px;
    color: @text;
    padding: 6px 14px;
    min-height: 20px;
    box-shadow: none;
    text-shadow: none;
    transition: 120ms;
}

button:hover {
    background-color: @border;
}

button:active,
button:checked,
button:focus:checked {
    background-color: @accent;
    border-color: @accent;
    color: @accent_text;
}

button.suggested-action {
    background-color: @accent;
    border-color: @accent;
    color: @accent_text;
}

button.suggested-action:hover {
    opacity: 0.92;
}

button.destructive-action {
    background-color: @danger;
    border-color: @danger;
    color: #FFFFFF;
}

button.flat {
    background-color: transparent;
    border: 1px solid transparent;
    border-radius: 8px;
}

button.flat:hover {
    background-color: alpha(@text, 0.10);
}

/* -------------------------------------------------------------- поля */

entry {
    background-color: @surface2;
    border: 1px solid @border;
    border-radius: 8px;
    color: @text;
    padding: 6px 10px;
    box-shadow: none;
    caret-color: @accent;
}

entry:focus {
    border-color: @accent;
    box-shadow: 0 0 0 1px @accent;
}

entry progress {
    background-color: alpha(@accent, 0.25);
}

spinbutton {
    background-color: @surface2;
    border: 1px solid @border;
    border-radius: 8px;
}

spinbutton>entry {
    background: transparent;
    border: none;
}

/* ------------------------------------------------------------ переключатели */

switch {
    background-color: @surface2;
    border: 1px solid @border;
    border-radius: 14px;
    min-width: 48px;
    min-height: 26px;
}

switch:checked {
    background-color: @accent;
    border-color: @accent;
}

switch slider {
    background-color: #FFFFFF;
    border-radius: 12px;
    min-width: 20px;
    min-height: 20px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.25);
}

/* ------------------------------------------------------------- ползунки */

scale trough {
    background-color: @surface2;
    border-radius: 4px;
    min-height: 6px;
}

scale highlight {
    background-color: @accent;
    border-radius: 4px;
}

scale slider {
    background-color: @surface;
    border: 2px solid @accent;
    border-radius: 12px;
    min-width: 16px;
    min-height: 16px;
    box-shadow: 0 1px 2px rgba(0,0,0,0.18);
}

/* ---------------------------------------------------------- флажки, радио */

check,
radio {
    min-width: 18px;
    min-height: 18px;
    background-color: @surface2;
    border: 1px solid @border;
    border-radius: 9px;
    color: @accent_text;
}

check:checked,
radio:checked {
    background-color: @accent;
    border-color: @accent;
}

checkmenuitem:checked,
radiomenuitem:checked {
    color: @accent;
}

/* ----------------------------------------------------------- вкладки */

notebook {
    background-color: @bg;
}

notebook>header {
    background-color: @surface;
    border: none;
    border-bottom: 1px solid @border;
}

notebook>header tab {
    background-color: transparent;
    border: none;
    border-radius: 6px 6px 0 0;
    padding: 6px 12px;
    color: @sub;
}

notebook>header tab:checked {
    color: @accent;
    box-shadow: inset 0 -2px 0 @accent;
}

/* ------------------------------------------------------------- списки */

list,
treeview {
    background-color: @surface;
    color: @text;
    border: 1px solid @border;
    border-radius: 10px;
}

list row {
    padding: 4px 8px;
}

list row:selected,
treeview:selected {
    background-color: alpha(@accent, 0.30);
    color: @text;
}

.sidebar,
placessidebar {
    background-color: @surface;
    border-right: 1px solid @border;
}

.sidebar row:selected {
    background-color: alpha(@accent, 0.22);
}

/* -------------------------------------------------------------- меню */

menubar {
    background-color: @surface;
    color: @text;
    border-bottom: 1px solid @border;
}

menubar menuitem {
    padding: 4px 8px;
    border-radius: 6px;
}

menubar menuitem:hover {
    background-color: alpha(@accent, 0.18);
}

menu,
menu.menu {
    background-color: @surface;
    border: 1px solid @border;
    border-radius: 10px;
    padding: 4px;
}

menu menuitem {
    padding: 6px 16px;
    border-radius: 6px;
    color: @text;
}

menu menuitem:hover {
    background-color: alpha(@accent, 0.20);
}

menu separator {
    background-color: @border;
    min-height: 1px;
    margin: 4px 8px;
}

/* ------------------------------------------------------------ всплывающие */

popover,
popover > contents,
tooltip {
    background-color: @surface;
    border: 1px solid @border;
    border-radius: 12px;
    color: @text;
}

tooltip {
    padding: 6px 10px;
}

/* ---------------------------------------------------------- прочее */

progressbar trough {
    background-color: @surface2;
    border-radius: 4px;
    min-height: 6px;
}

progressbar progress {
    background-color: @accent;
    border-radius: 4px;
}

separator {
    background-color: @border;
}

link {
    color: @accent;
}

selection {
    background-color: alpha(@accent, 0.35);
    color: @text;
}

scrollbar slider {
    background-color: alpha(@text, 0.28);
    border-radius: 4px;
    min-width: 8px;
    min-height: 24px;
}

scrollbar trough {
    background-color: transparent;
}

.frame {
    border: 1px solid @border;
    border-radius: 10px;
}

.viewport {
    background-color: transparent;
}

.calendar {
    background-color: @surface;
    color: @text;
}
