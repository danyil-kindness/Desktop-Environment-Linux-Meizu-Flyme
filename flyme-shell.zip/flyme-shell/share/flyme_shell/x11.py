# -*- coding: utf-8 -*-
"""Минимальный EWMH-клиент через ctypes + libX11 (без внешних зависимостей)."""

import ctypes
import ctypes.util

_libname = ctypes.util.find_library("X11") or "libX11.so.6"
X = ctypes.CDLL(_libname)

X.XOpenDisplay.restype = ctypes.c_void_p
X.XOpenDisplay.argtypes = [ctypes.c_char_p]
X.XCloseDisplay.argtypes = [ctypes.c_void_p]
X.XInternAtom.restype = ctypes.c_ulong
X.XInternAtom.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
X.XGetWindowProperty.restype = ctypes.c_int
X.XGetWindowProperty.argtypes = [
    ctypes.c_void_p,              # display
    ctypes.c_ulong,               # window
    ctypes.c_ulong,               # property
    ctypes.c_long,                # long_offset
    ctypes.c_long,                # long_length
    ctypes.c_int,                 # delete
    ctypes.c_ulong,               # req_type (AnyPropertyType=0)
    ctypes.POINTER(ctypes.c_ulong),   # actual_type
    ctypes.POINTER(ctypes.c_int),     # actual_format
    ctypes.POINTER(ctypes.c_ulong),   # nitems
    ctypes.POINTER(ctypes.c_ulong),   # bytes_after
    ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)),  # prop
]
X.XFree.argtypes = [ctypes.c_void_p]
X.XSendEvent.restype = ctypes.c_int
X.XSendEvent.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int,
                         ctypes.c_long, ctypes.c_void_p]
X.XFlush.argtypes = [ctypes.c_void_p]
X.XChangeProperty.restype = ctypes.c_int
X.XChangeProperty.argtypes = [
    ctypes.c_void_p,              # display
    ctypes.c_ulong,               # window
    ctypes.c_ulong,               # property
    ctypes.c_ulong,               # type
    ctypes.c_int,                 # format
    ctypes.c_int,                 # mode (PropModeReplace = 0)
    ctypes.c_void_p,              # data
    ctypes.c_int,                 # nelements
]

ANY = 0


class XClientMessageEvent(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("serial", ctypes.c_ulong),
        ("send_event", ctypes.c_int),
        ("display", ctypes.c_void_p),
        ("window", ctypes.c_ulong),
        ("message_type", ctypes.c_ulong),
        ("format", ctypes.c_int),
        ("data", ctypes.c_long * 5),
    ]


class XEvent(ctypes.Union):
    _fields_ = [
        ("type", ctypes.c_int),
        ("xclient", XClientMessageEvent),
        ("pad", ctypes.c_long * 24),  # sizeof(XEvent) у Xlib = 24 long
    ]


_display = None


def display():
    global _display
    if _display is None:
        _display = X.XOpenDisplay(None)
    return _display


def atom(name):
    disp = display()
    if not disp:
        return 0
    return X.XInternAtom(disp, name.encode("utf-8"), 0)


def _prop(win, name, max_len=8192):
    """-> (fmt, data_bytes, nitems) либо None."""
    disp = display()
    if not disp or not win:
        return None
    a = atom(name)
    if not a:
        return None
    actual_type = ctypes.c_ulong()
    actual_format = ctypes.c_int()
    nitems = ctypes.c_ulong()
    bytes_after = ctypes.c_ulong()
    prop = ctypes.POINTER(ctypes.c_ubyte)()
    status = X.XGetWindowProperty(
        disp, win, a, 0, max_len, 0, ANY,
        ctypes.byref(actual_type), ctypes.byref(actual_format),
        ctypes.byref(nitems), ctypes.byref(bytes_after), ctypes.byref(prop),
    )
    if status != 0 or not prop:
        return None
    fmt = actual_format.value
    n = nitems.value
    if fmt == 32:
        size = ctypes.sizeof(ctypes.c_long) * n
    elif fmt == 16:
        size = 2 * n
    else:
        size = n
    data = ctypes.string_at(prop, size) if size else b""
    X.XFree(prop)
    return fmt, data, n


def _card32(win, name):
    got = _prop(win, name)
    if not got or got[0] != 32:
        return []
    fmt, data, n = got
    arr = (ctypes.c_ulong * n).from_buffer_copy(data)
    return [int(v) for v in arr]


def client_list():
    wins = _card32(atom_root(), "_NET_CLIENT_LIST")
    if not wins:
        wins = _card32(atom_root(), "_NET_CLIENT_LIST_STACKING")
    return [w for w in wins if w]


def atom_root():
    disp = display()
    return X.XDefaultRootWindow(disp) if disp else 0


def window_name(win):
    got = _prop(win, "_NET_WM_NAME")
    if got and got[0] == 8 and got[1]:
        try:
            return got[1].split(b"\0", 1)[0].decode("utf-8", "replace")
        except Exception:
            return ""
    return ""


def wm_class(win):
    got = _prop(win, "WM_CLASS")
    if got and got[0] == 8 and got[1]:
        parts = got[1].split(b"\0")
        parts = [p.decode("utf-8", "replace") for p in parts if p]
        return parts
    return []


def active_window():
    vals = _card32(atom_root(), "_NET_ACTIVE_WINDOW")
    return vals[0] if vals else 0


def _client_message(win, message, data):
    disp = display()
    if not disp:
        return
    ev = XEvent()
    ev.xclient.type = 33  # ClientMessage
    ev.xclient.display = disp
    ev.xclient.window = win
    ev.xclient.message_type = atom(message)
    ev.xclient.format = 32
    for i, val in enumerate(data[:5]):
        ev.xclient.data[i] = val
    X.XSendEvent(disp, atom_root(), 0,
                 ctypes.c_long(0), ctypes.byref(ev))
    X.XFlush(disp)


def activate_window(win):
    # https://specifications.freedesktop.org/wm-spec — _NET_ACTIVE_WINDOW
    _client_message(win, "_NET_ACTIVE_WINDOW", [2, 0, 0, 0, 0])


def close_window(win):
    _client_message(win, "_NET_CLOSE_WINDOW", [0, 0, 1, 0, 0])


def _set_cardinals(win, name, values):
    """Записать свойство CARDINAL[32] на окно."""
    disp = display()
    if not disp or not win:
        return
    prop = atom(name)
    card = atom("CARDINAL")
    if not prop or not card:
        return
    arr = (ctypes.c_long * len(values))(*values)
    X.XChangeProperty(disp, win, prop, card, 32, 0,
                      ctypes.byref(arr), len(values))
    X.XFlush(disp)


def set_strut(window, side, size, content_w, content_h, offset=0):
    """Зарезервировать полосу под панель (_NET_WM_STRUT_PARTIAL).

    side: 'top' | 'bottom'; offset — смещение начала полосы по X.
    Свойство ставится прямо на окно клиента: именно его читает WM.
    """
    try:
        xid = window.get_xid()
    except Exception:
        return
    if not xid:
        return
    vals = [0] * 12
    if side == "top":
        vals[2] = size
        vals[8] = offset
        vals[9] = offset + content_w
    elif side == "bottom":
        vals[3] = size
        vals[10] = offset
        vals[11] = offset + content_w
    else:
        return
    _set_cardinals(xid, "_NET_WM_STRUT_PARTIAL", vals)
    # упрощённый вариант для старых WM
    _set_cardinals(xid, "_NET_WM_STRUT", vals[:4])


def tokens_for_window(win):
    """Набор токенов для сопоставления окна с приложением."""
    import re  # noqa: PLC0415
    parts = wm_class(win) + [window_name(win)]
    text = " ".join(parts).lower()
    return set(re.findall(r"[a-z0-9]+", text))
