# -*- coding: utf-8 -*-
"""Верхняя панель Flyme: часы, календарь, статусы, центр управления."""

import datetime
import os
import subprocess

from gi.repository import Gdk, Gio, GLib, Gtk

from . import config, i18n, sysinfo, tasklist, theme, widgets, windows, x11
from .i18n import _


def _spawn(cmd):
    try:
        subprocess.Popen(cmd, start_new_session=True)
    except Exception:
        pass


class PanelApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.flyme.Panel")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(PanelWindow(self))
        self.win.present()


class PanelWindow(widgets.ThemedWindow):
    def __init__(self, app):
        super().__init__()
        self.set_title("Flyme Panel")
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_decorated(False)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        widgets.set_rgba(self)

        cfg = config.load()
        self.height = cfg.getint("panel", "height", fallback=36)
        self.show_date = cfg.getboolean("panel", "show_date", fallback=True)
        self.dnd = cfg.getboolean("general", "dnd", fallback=False)

        self._calendar = None
        self._build_ui()
        self.show_all()
        geo = widgets.primary_geometry()
        self.set_size_request(geo.width, self.height)
        self.move(geo.x, max(0, geo.y))
        widgets.GLib_idle_strut(self.get_window(), "top", self.height)

        GLib.timeout_add_seconds(1, self._tick_clock)
        GLib.timeout_add_seconds(5, self._tick_sys)
        self._tick_clock()
        self._tick_sys()

    # ------------------------------------------------------------- построение

    def _build_ui(self):
        pal = theme.palette()
        tc = pal["panel_text"]
        sc = pal["panel_sub"]

        self.css_prov = widgets.css_provider(self.build_css())

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        box.set_margin_start(6)
        box.set_margin_end(6)

        # слева: лаунчер + часы
        self.menu_btn = widgets.icon_button("grid", tc, icon_size=18,
                                            tooltip=_("Приложения (Super+Пробел)"))
        self.menu_btn.connect("clicked", lambda *_: _spawn(["flyme-launcher"]))
        box.pack_start(self.menu_btn, False, False, 0)

        self.clock_btn = Gtk.Button()
        self.clock_btn.set_relief(Gtk.ReliefStyle.NONE)
        self.clock_btn.set_can_focus(False)
        self.clock_label = Gtk.Label(label="")
        self.clock_label.get_style_context().add_class("flyme-clock")
        self.clock_btn.add(self.clock_label)
        self.clock_btn.connect("clicked", self._on_clock_clicked)
        box.pack_start(self.clock_btn, False, False, 8)

        # открытые окна — по центру панели
        self.tasks = tasklist.TaskList()
        box.pack_start(self.tasks, True, True, 10)

        # справа: статусы
        right = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        self.batt_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.batt_icon = widgets.IconArea("battery", sc, 18)
        self.batt_label = Gtk.Label(label="")
        self.batt_label.get_style_context().add_class("flyme-status")
        self.batt_box.pack_start(self.batt_icon, False, False, 0)
        self.batt_box.pack_start(self.batt_label, False, False, 0)
        right.pack_start(self.batt_box, False, False, 6)

        self.wifi_btn = widgets.icon_button("wifi", sc, icon_size=18,
                                            tooltip="Wi-Fi")
        self.wifi_btn.connect("clicked", self._on_wifi_clicked)
        right.pack_start(self.wifi_btn, False, False, 0)

        self.vol_btn = widgets.icon_button("volume", sc, icon_size=18,
                                           tooltip=_("Громкость: колесо — регулировка"))
        self.vol_btn.connect("clicked", self._on_volume_clicked)
        right.pack_start(self.vol_btn, False, False, 0)

        self.dnd_btn = widgets.icon_button("bell", sc, icon_size=18,
                                           tooltip=_("Уведомления: «Не беспокоить»"))
        self.dnd_btn.connect("clicked", self._on_dnd_clicked)
        right.pack_start(self.dnd_btn, False, False, 0)

        self.cc_btn = widgets.icon_button("gear", tc, icon_size=18,
                                          tooltip=_("Центр управления (Super+A)"))
        self.cc_btn.connect("clicked", lambda *_: _spawn(["flyme-control-center"]))
        right.pack_start(self.cc_btn, False, False, 0)

        # прокрутка на статусной области: громкость, Shift — яркость
        ev = Gtk.EventBox()
        ev.add(right)
        ev.set_visible_window(False)
        ev.connect("scroll-event", self._on_scroll)
        ev.connect("button-press-event", self._on_status_press)
        box.pack_end(ev, False, False, 0)

        self.add(box)
        self.get_style_context().add_class("flyme-panel")
        self.clock_btn.get_style_context().add_class("flyme-clockbtn")
        self.use_css(self.css_prov)

        # контекстное меню панели
        self.connect("button-press-event", self._on_panel_press)

    def build_css(self):
        pal = theme.palette()
        t = pal["panel_rgba"]
        txt = "rgb(%d,%d,%d)" % tuple(round(c * 255) for c in pal["panel_text"])
        sub = "rgb(%d,%d,%d)" % tuple(round(c * 255) for c in pal["panel_sub"])
        accent = pal["accent"]
        return """
            window.flyme-panel {{
                background-color: rgba({tr},{tg},{tb},{ta});
                color: {txt};
            }}
            .flyme-clock, .flyme-status {{
                color: {txt};
                font-size: 11.5px;
                font-weight: bold;
            }}
            .flyme-clockbtn {{
                background: transparent; border: none; border-radius: 6px;
                padding: 2px 8px;
            }}
            .flyme-clockbtn:hover {{
                background-color: rgba(127,127,127,0.18);
            }}
            .flyme-task {{
                background: transparent;
                border: none;
                border-radius: 8px;
                padding: 3px 8px;
                min-height: 26px;
            }}
            .flyme-task:hover {{
                background-color: rgba(127,127,127,0.20);
            }}
            .flyme-task-active {{
                background-color: rgba(0,136,255,0.26);
            }}
            .flyme-task-active:hover {{
                background-color: rgba(0,136,255,0.34);
            }}
            .flyme-task label {{
                color: {txt};
                font-size: 11.5px;
            }}
            menu, menuitem {{
                background-color: {surface};
                color: {text};
                border: 1px solid {border};
                border-radius: 10px;
                padding: 4px;
            }}
            menuitem {{
                padding: 6px 14px;
                border: none;
                border-radius: 6px;
            }}
            menuitem:hover {{
                background-color: {accent_soft};
                color: {text};
            }}
        """.format(
            tr=round(t[0] * 255), tg=round(t[1] * 255), tb=round(t[2] * 255), ta=t[3],
            txt=txt, sub=sub, accent=pal["accent"],
            accent_soft=theme.css_rgba(pal["accent"], 0.18),
            surface=pal["surface"], text=pal["text"], border=pal["border"],
        )

    def apply_theme(self):
        self.dnd = config.load().getboolean("general", "dnd", fallback=False)
        pal = theme.palette()
        widgets.update_provider(self.css_prov, self.build_css())
        tc = pal["panel_text"]
        sc = pal["panel_sub"]
        self.menu_btn.icon_area.set_icon(color=tc)
        self.cc_btn.icon_area.set_icon(color=tc)
        self._tick_sys()

    # ---------------------------------------------------------------- часы

    def _tick_clock(self):
        now = datetime.datetime.now()
        if self.show_date:
            txt = "%s %s · %s" % (
                widgets.ru_weekday(now), now.strftime("%d.%m"), now.strftime("%H:%M")
            )
        else:
            txt = now.strftime("%H:%M")
        if self.clock_label.get_text() != txt:
            self.clock_label.set_text(txt)
        # на блокировке и в полноэкранных приложениях (видео, игры, лаунчер)
        # панель убирается с экрана
        hide = config.is_locked() or windows.is_fullscreen(windows.active_app())
        if hide:
            if self.get_visible():
                self.hide()
        elif not self.get_visible() or not self.get_mapped():
            # панель не должна теряться: показываем заново, если окно
            # скрылось или его размапил оконный менеджер
            self.show_all()
            self.deiconify()
        return True

    def _on_clock_clicked(self, *_args):
        self._show_calendar()

    def _show_calendar(self):
        if getattr(self, "_calendar", None) is not None:
            self._hide_calendar()
        pop = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        pop.set_title(_("Календарь"))
        pop.set_type_hint(Gdk.WindowTypeHint.POPUP_MENU)
        pop.set_decorated(False)
        pop.set_resizable(False)
        pop.set_skip_taskbar_hint(True)
        pop.set_skip_pager_hint(True)
        pop.set_keep_above(True)
        pop.set_transient_for(self)
        pop.set_accept_focus(True)
        widgets.set_rgba(pop)
        pop.get_style_context().add_class("flyme-popover")
        self._calendar = pop

        now = datetime.datetime.now()
        grid = Gtk.Grid()
        grid.get_style_context().add_class("flyme-calendar")
        grid.set_row_spacing(2)
        grid.set_column_spacing(2)
        grid.set_margin_top(8)
        grid.set_margin_bottom(8)
        grid.set_margin_start(10)
        grid.set_margin_end(10)

        title = Gtk.Label()
        title.set_markup(
            "<b>%s %d</b>" % (i18n.months_nom()[now.month - 1], now.year)
        )
        title.set_margin_bottom(6)
        grid.attach(title, 0, 0, 7, 1)

        for i, d in enumerate(i18n.days_short()):
            lbl = Gtk.Label(label=d)
            lbl.get_style_context().add_class("flyme-dayname")
            if i >= 5:
                lbl.get_style_context().add_class("flyme-weekend")
            grid.attach(lbl, i, 1, 1, 1)

        import calendar as _cal  # noqa: PLC0415
        cal = _cal.Calendar(firstweekday=0).monthdayscalendar(now.year, now.month)
        row = 2
        for week in cal:
            for i, day in enumerate(week):
                if day == 0:
                    continue
                lbl = Gtk.Label(label=str(day))
                if day == now.day:
                    lbl.get_style_context().add_class("flyme-today")
                elif i >= 5:
                    lbl.get_style_context().add_class("flyme-weekend")
                grid.attach(lbl, i, row, 1, 1)
            row += 1

        pop.add(grid)
        widgets.apply_css_screen("""
            window.flyme-popover {{
                background-color: transparent;
            }}
            window.flyme-popover > decoration {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 14px;
            }}
            .flyme-calendar {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 14px;
                color: {text};
                padding: 4px 6px;
            }}
            .flyme-calendar .flyme-dayname {{ color: {sub}; font-size: 11px; }}
            .flyme-calendar .flyme-weekend {{ color: {danger}; }}
            .flyme-calendar .flyme-today {{
                background-color: {accent}; color: {accent_text};
                border-radius: 8px; font-weight: bold;
            }}
            .flyme-calendar label {{ min-width: 26px; min-height: 22px; font-size: 12px; }}
        """.format(**theme.palette()))
        pop.show_all()
        # под часами
        px, py = self.get_position()
        try:
            cx, _cy = self.clock_btn.translate_coordinates(self, 0, 0)
        except Exception:
            cx = self.clock_btn.get_allocation().x
        pop.move(px + cx, py + self.height + 4)
        pop.present()
        # замыкание не должно держать ссылку на pop: иначе PyGObject
        # финализирует окно позже и процесс может упасть
        pop.connect("focus-out-event", self._on_calendar_focus_out)
        pop.connect("key-press-event", self._on_calendar_key)

    def _on_calendar_focus_out(self, *_args):
        GLib.idle_add(self._hide_calendar)
        return False

    def _hide_calendar(self):
        pop = getattr(self, "_calendar", None)
        self._calendar = None
        if pop is not None:
            try:
                pop.destroy()
            except Exception:
                pass
        return False

    def _on_calendar_key(self, _win, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self._hide_calendar()
            return True
        return False

    # ------------------------------------------------------------ статусы

    def _tick_sys(self):
        pal = theme.palette()
        sc = pal["panel_sub"]
        acc = theme.hex_rgba(pal["accent"])[:3]

        bat = sysinfo.battery()
        if bat is None:
            self.batt_box.hide()
        else:
            cap, charging = bat
            self.batt_box.show()
            color = sc
            if charging:
                color = theme.hex_rgba(pal["success"])[:3]
            elif cap <= 20:
                color = theme.hex_rgba(pal["danger"])[:3]
            self.batt_icon.set_icon(color=color, level=cap / 100.0,
                                    charging=charging)
            self.batt_label.set_text("%d%%" % cap)

        wifi = sysinfo.wifi_enabled()
        if wifi is None:
            self.wifi_btn.hide()
        else:
            self.wifi_btn.show()
            self.wifi_btn.icon_area.set_icon(
                name="wifi" if wifi else "wifi-off",
                color=(acc if wifi else sc),
            )

        mute = sysinfo.get_mute()
        vol = sysinfo.get_volume()
        self.vol_btn.icon_area.set_icon(
            name="volume-mute" if mute else "volume",
            color=(theme.hex_rgba(pal["danger"])[:3] if mute else sc),
        )
        self.vol_btn.set_tooltip_text(
            _("Громкость: %s · колесо — регулировка, Shift+колесо — яркость")
            % (_("выкл") if mute else "%d%%" % (vol if vol is not None else 0))
        )

        self.dnd_btn.icon_area.set_icon(
            name=("moon" if self.dnd else "bell"),
            color=(acc if self.dnd else sc),
        )
        self.dnd_btn.set_tooltip_text(
            _("«Не беспокоить»: вкл") if self.dnd else _("«Не беспокоить»: выкл")
        )
        return True

    def _on_wifi_clicked(self, *_a):
        cur = sysinfo.wifi_enabled()
        if cur is not None:
            sysinfo.set_wifi(not cur)
        GLib.timeout_add_seconds(1, self._tick_sys)

    def _on_volume_clicked(self, *_a):
        sysinfo.toggle_mute()
        self._tick_sys()

    def _on_dnd_clicked(self, *_a):
        self.dnd = not self.dnd
        config.set_option("general", "dnd", "true" if self.dnd else "false")
        self._tick_sys()

    def _on_scroll(self, _w, ev):
        direction = ev.direction
        if direction not in (Gdk.ScrollDirection.UP, Gdk.ScrollDirection.DOWN):
            return False
        delta = 5 if direction == Gdk.ScrollDirection.UP else -5
        if ev.state & Gdk.ModifierType.SHIFT_MASK:
            cur = sysinfo.get_brightness()
            if cur is not None:
                sysinfo.set_brightness(cur + delta)
        else:
            cur = sysinfo.get_volume() or 0
            sysinfo.set_volume(cur + delta)
        self._tick_sys()
        return True

    def _on_status_press(self, _w, ev):
        if ev.button == 1:
            _spawn(["flyme-control-center"])
            return True
        return False

    def _on_panel_press(self, _w, ev):
        if ev.button != 3:
            return False
        menu = Gtk.Menu()
        items = [
            (_("Лаунчер приложений"), lambda *_: _spawn(["flyme-launcher"])),
            (_("Центр управления"), lambda *_: _spawn(["flyme-control-center"])),
            (_("Заблокировать"), lambda *_: sysinfo.lock_screen()),
            (None, None),
            (_("Перезапустить панель"), self._restart_panel),
            (_("Выйти из сеанса Flyme"), lambda *_: sysinfo.logout()),
        ]
        for label, cb in items:
            if label is None:
                menu.append(Gtk.SeparatorMenuItem())
                continue
            mi = Gtk.MenuItem(label=label)
            if cb:
                mi.connect("activate", cb)
            menu.append(mi)
        menu.show_all()
        menu.connect("selection-done", lambda m: GLib.idle_add(m.destroy))
        menu.popup_at_pointer(ev)
        return True

    def _restart_panel(self, *_a):
        _spawn(["flyme-panel"])
        GLib.timeout_add_seconds(1, Gio.Application.get_default().quit)


def main():
    # Gtk.Application — единственный экземпляр панели
    PanelApp().run([])


if __name__ == "__main__":
    main()
