# -*- coding: utf-8 -*-
"""Экран блокировки Flyme (эстетический; для защиты — light-locker, см. README)."""

import datetime

from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk

from . import config, theme, widgets
from .i18n import _

PANEL_GAP = 40


class LockApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.flyme.Lock")
        self.windows = []

    def do_activate(self):
        if self.windows:
            return
        config.set_locked()
        display = Gdk.Display.get_default()
        for i in range(display.get_n_monitors()):
            win = self.track(LockWindow(self, display.get_monitor(i)))
            self.windows.append(win)
            win.show_all()
        GLib.timeout_add_seconds(1, self._tick)

    def _tick(self):
        alive = False
        for win in self.windows:
            if win.get_realized():
                win._update_clock()
                alive = True
        if not alive:
            config.clear_locked()
            self.quit()
            return False
        return True

    def unlock(self):
        config.clear_locked()
        self.quit()


class LockWindow(Gtk.Window):
    def __init__(self, app, monitor):
        super().__init__()
        self.lock_app = app
        self.monitor = monitor
        self.set_title("Flyme Lock")
        self.set_type_hint(Gdk.WindowTypeHint.NORMAL)
        self.set_decorated(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(True)
        self.set_can_focus(True)
        widgets.set_rgba(self)
        self.get_style_context().add_class("flyme-lock")

        pal = theme.palette()
        css = """
            window.flyme-lock {
                background-color: #0A0C10;
            }
            .flyme-lock-scrim {
                background-color: rgba(0,0,0,{scrim});
            }
            .flyme-clocklabel {
                color: #FFFFFF; font-size: 88px; font-weight: 200;
            }
            .flyme-datlabel {
                color: rgba(255,255,255,0.75); font-size: 20px;
            }
            .flyme-hintlabel {
                color: rgba(255,255,255,0.45); font-size: 13px;
            }
            .flyme-unlockbtn {
                background-color: rgba(0,136,255,0.85);
                color: #FFFFFF;
                border: none;
                border-radius: 26px;
                padding: 14px 44px;
                font-size: 16px;
            }
            .flyme-unlockbtn:hover {
                background-color: rgba(0,136,255,1.0);
            }
        """
        widgets.apply_css_screen(css.replace(
            "{scrim}", "0.52" if not config.is_dark() else "0.30"))

        geo = self.monitor.get_geometry() if self.monitor is not None \
            else widgets.primary_geometry()
        bg = Gtk.Image()
        bg.set_hexpand(True)
        bg.set_vexpand(True)
        wallpaper = "/usr/share/backgrounds/flyme/flyme-%s.png" % (
            "dark" if config.is_dark() else "light")
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                wallpaper, max(1, geo.width), max(1, geo.height), False)
            bg.set_from_pixbuf(pb)
        except Exception:
            pass

        overlay = Gtk.Overlay()
        overlay.add(bg)
        scrim = Gtk.EventBox()
        scrim.set_visible_window(True)
        scrim.set_can_focus(False)
        scrim.get_style_context().add_class("flyme-lock-scrim")
        overlay.add_overlay(scrim)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        vbox.set_valign(Gtk.Align.CENTER)
        vbox.set_halign(Gtk.Align.CENTER)

        self.clock = Gtk.Label()
        self.clock.get_style_context().add_class("flyme-clocklabel")
        vbox.pack_start(self.clock, False, False, 0)

        self.date = Gtk.Label()
        self.date.get_style_context().add_class("flyme-datlabel")
        vbox.pack_start(self.date, False, False, 20)

        btn = Gtk.Button(label=_("Разблокировать"))
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.get_style_context().add_class("flyme-unlockbtn")
        btn.connect("clicked", lambda *_: app.unlock())
        vbox.pack_start(btn, False, False, 24)

        hint = Gtk.Label(label=_("Нажмите Enter или Esc, чтобы разблокировать"))
        hint.get_style_context().add_class("flyme-hintlabel")
        vbox.pack_start(hint, False, False, 0)

        overlay.add_overlay(vbox)
        self.add(overlay)
        self.connect("key-press-event", self._on_key)
        self.connect("button-press-event", lambda *_: False)
        self._update_clock()

    def do_show(self):
        Gtk.Window.do_show(self)
        geo = self.monitor.get_geometry() if self.monitor is not None \
            else widgets.primary_geometry()
        widgets.fullscreen_on_geometry(self, geo)
        self.grab_focus()

    def _update_clock(self):
        now = datetime.datetime.now()
        self.clock.set_text(now.strftime("%H:%M"))
        self.date.set_text("%s, %s" % (widgets.ru_weekday(now).capitalize(),
                                       widgets.ru_date(now)))

    def _on_key(self, _w, ev):
        from gi.repository import Gdk as _G  # noqa: PLC0415
        if ev.keyval in (_G.KEY_Escape, _G.KEY_Return, _G.KEY_KP_Enter,
                         _G.KEY_space):
            self.lock_app.unlock()
            return True
        return False


def main():
    LockApp().run([])


if __name__ == "__main__":
    main()
