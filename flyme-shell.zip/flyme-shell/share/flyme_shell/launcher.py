# -*- coding: utf-8 -*-
"""Лаунчер приложений: полноэкранный оверлей с поиском (стиль Flyme)."""

from gi.repository import Gdk, Gio, GLib, Gtk, Pango

from . import apps, theme, widgets
from .i18n import _


class LauncherApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.flyme.Launcher")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(LauncherWindow(self))
        self.win.toggle()


class LauncherWindow(widgets.ThemedWindow):
    def __init__(self, app):
        super().__init__()
        self.set_title("Flyme Launcher")
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(True)
        # поверх обычных окон, но не поверх верхней панели: лаунчер занимает
        # рабочую область под панелью, поэтому панель остаётся видимой
        self.set_keep_above(True)
        widgets.set_rgba(self)
        self.get_style_context().add_class("flyme-launcher")
        self.css_prov = widgets.css_provider(self.build_css())
        self.use_css(self.css_prov)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
        outer.set_margin_top(56)
        outer.set_margin_start(0)
        outer.set_margin_end(0)

        # поиск
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text(_("Поиск приложений…"))
        self.search.set_halign(Gtk.Align.CENTER)
        self.search.set_size_request(560, 46)
        self.search.get_style_context().add_class("flyme-search")
        self.search.connect("changed", self._on_search_changed)
        self.search.connect("key-press-event", self._on_search_key)

        # подсказка внутри поля: штатный placeholder GTK не виден на тёмном фоне
        self.search_ph = Gtk.Label(label=_("Поиск приложений…"))
        self.search_ph.set_halign(Gtk.Align.START)
        self.search_ph.set_valign(Gtk.Align.CENTER)
        self.search_ph.set_margin_start(54)
        self.search_ph.set_can_focus(False)
        self.search_ph.get_style_context().add_class("flyme-search-ph")
        search_overlay = Gtk.Overlay()
        search_overlay.set_halign(Gtk.Align.CENTER)
        search_overlay.add(self.search)
        search_overlay.add_overlay(self.search_ph)
        outer.pack_start(search_overlay, False, False, 0)

        # сетка приложений
        self.flow = Gtk.FlowBox()
        self.flow.set_valign(Gtk.Align.START)
        self.flow.set_halign(Gtk.Align.CENTER)
        self.flow.set_max_children_per_line(8)
        self.flow.set_min_children_per_line(2)
        self.flow.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.flow.set_activate_on_single_click(False)
        self.flow.set_homogeneous(True)
        self.flow.set_column_spacing(6)
        self.flow.set_row_spacing(10)
        self.flow.connect("child-activated", self._on_child_activated)
        self.flow.connect("move-cursor", self._on_move_cursor)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        # обычная (не всплывающая) полоса прокрутки: её видно и удобно тянуть
        scroller.set_overlay_scrolling(False)
        scroller.set_vexpand(True)
        scroller.add(self.flow)
        scroller.get_style_context().add_class("flyme-scroll")
        outer.pack_start(scroller, True, True, 0)

        hint = Gtk.Label()
        hint.set_markup("<span size='small' alpha='68%%'>"
                        + _("Колесо мыши — прокрутка · Enter — запустить · "
                            "Esc — закрыть")
                        + "</span>")
        hint.set_halign(Gtk.Align.CENTER)
        outer.pack_start(hint, False, False, 0)

        self.add(outer)
        self.connect("key-press-event", self._on_key)

        self.all_apps = apps.list_apps()
        self.visible_apps = list(self.all_apps)
        self._fill(self.all_apps)

        # показ на первичном мониторе
        self.connect("show", self._on_show)

    # ---------------------------------------------------------------- тема

    def build_css(self):
        pal = theme.palette()
        o = pal["overlay"]
        return """
            window.flyme-launcher {{
                background-color: rgba({or_},{og},{ob},{oa});
            }}
            .flyme-search {{
                background-color: rgba(127,127,127,0.16);
                border: none;
                border-radius: 23px;
                padding: 0 22px;
                color: #F2F3F5;
                font-size: 16px;
                caret-color: {accent};
            }}
            .flyme-search-ph {{
                color: rgba(255,255,255,0.45);
                font-size: 16px;
            }}
            .flyme-search:focus {{
                background-color: rgba(127,127,127,0.24);
                box-shadow: 0 0 0 2px {accent};
            }}
            .flyme-app {{
                background: transparent; border: none;
                border-radius: 16px; padding: 10px 4px;
                color: #F2F3F5;
            }}
            .flyme-app:hover {{
                background-color: rgba(127,127,127,0.22);
            }}
            .flyme-app:selected {{
                background-color: rgba(0,136,255,0.35);
            }}
            .flyme-applabel {{
                color: #F2F3F5; font-size: 11px;
            }}
            .flyme-scroll, .flyme-scroll frame,
            .flyme-scroll viewport, .flyme-scroll scrolledwindow {{
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar {{
                min-width: 14px;
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar trough {{
                background: transparent;
                border: none;
                box-shadow: none;
            }}
            scrollbar slider {{
                background-color: rgba(255,255,255,0.52);
                border: none;
                border-radius: 5px;
                min-width: 10px;
                min-height: 48px;
            }}
            scrollbar slider:hover {{
                background-color: rgba(255,255,255,0.68);
            }}
            scrollbar slider:active {{
                background-color: rgba(255,255,255,0.88);
            }}
            scrollbar button {{
                min-width: 0; min-height: 0;
                padding: 0; margin: 0;
                border: none;
                background: none;
                box-shadow: none;
            }}
        """.format(
            or_=round(o[0] * 255), og=round(o[1] * 255),
            ob=round(o[2] * 255), oa=o[3],
            text=pal["text"], accent=pal["accent"],
        )

    def apply_theme(self):
        widgets.update_provider(self.css_prov, self.build_css())

    # ------------------------------------------------------------ наполнение

    def _fill(self, plist):
        for child in self.flow.get_children():
            self.flow.remove(child)
        icon_theme = Gtk.IconTheme.get_default()
        for app in plist:
            btn = Gtk.Button()
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_can_focus(False)
            btn.get_style_context().add_class("flyme-app")
            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            pb = app.icon_pixbuf(56)
            img = Gtk.Image()
            if pb is not None:
                img.set_from_pixbuf(pb)
            else:
                img.set_from_icon_name("application-x-executable", Gtk.IconSize.DIALOG)
            img.set_halign(Gtk.Align.CENTER)
            vbox.pack_start(img, False, False, 0)
            label = Gtk.Label(label=app.name)
            label.set_ellipsize(Pango.EllipsizeMode.END)
            label.set_max_width_chars(12)
            label.set_lines(2)
            label.set_line_wrap(False)
            label.set_halign(Gtk.Align.CENTER)
            label.get_style_context().add_class("flyme-applabel")
            vbox.pack_start(label, False, False, 0)
            btn.add(vbox)
            btn.connect("clicked", self._on_button_clicked, app)
            self.flow.add(btn)
            btn.app_ref = app
        self.flow.show_all()
        _theme = icon_theme

    def _on_search_changed(self, entry):
        query = entry.get_text().strip()
        self.search_ph.set_visible(not query)
        self.visible_apps = [a for a in self.all_apps if a.matches(query)]
        self._fill(self.visible_apps)

    # ------------------------------------------------------------- запуск

    def _launch(self, app):
        app.launch()
        self.hide()

    def _on_button_clicked(self, _btn, app):
        self._launch(app)

    def _on_child_activated(self, _fb, child):
        btn = child.get_child()
        app = getattr(btn, "app_ref", None)
        if app:
            self._launch(app)

    # ------------------------------------------------------------ клавиатура

    def _first_app(self):
        if not self.visible_apps:
            return None
        row = self.flow.get_children()
        if not row:
            return None
        sel = self.flow.get_selected_children()
        if sel:
            btn = sel[0].get_child()
            app = getattr(btn, "app_ref", None)
            if app:
                return app
        btn = row[0].get_child()
        return getattr(btn, "app_ref", None)

    def _on_search_key(self, _w, ev):
        key = ev.keyval
        if key in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_ISO_Enter):
            app = self._first_app()
            if app:
                self._launch(app)
            return True
        if key == Gdk.KEY_Escape:
            self.hide()
            return True
        if key == Gdk.KEY_Down:
            self.flow.grab_focus()
            return True
        return False

    def _on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.hide()
            return True
        return False

    def _on_move_cursor(self, _fb, _step, _count):
        return False

    # ---------------------------------------------------------------- показ

    def _on_show(self, *_a):
        geo = widgets.workarea_geometry()
        self.move(geo.x, geo.y)
        self.resize(geo.width, geo.height)
        GLib.idle_add(lambda: (self.search.grab_focus(), False)[1])

    def toggle(self):
        if self.get_visible():
            self.hide()
        else:
            self.search.set_text("")
            self._fill(self.all_apps)
            self.show_all()
            self.present()


def main():
    LauncherApp().run([])


if __name__ == "__main__":
    main()
