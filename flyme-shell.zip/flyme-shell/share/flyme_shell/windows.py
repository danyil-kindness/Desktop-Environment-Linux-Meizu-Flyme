# -*- coding: utf-8 -*-
"""Окна других приложений через libwnck (EWMH): список, активное, геометрия."""

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import GdkPixbuf, Gtk  # noqa: E402,F401  (GTK инициализирует GDK)

try:
    gi.require_version("Wnck", "3.0")
    from gi.repository import Wnck  # noqa: E402
except (ValueError, ImportError):  # pragma: no cover - зависит от системы
    Wnck = None


_initialized = False
_screen = None
_screen_loaded = False


def _init():
    global _initialized
    if _initialized or Wnck is None:
        return
    _initialized = True
    try:
        Wnck.set_client_type(Wnck.ClientType.PAGER)
    except Exception:
        pass


def available():
    return Wnck is not None and screen() is not None


def screen():
    """Wnck.Screen для текущего дисплея (или None)."""
    global _screen, _screen_loaded
    _init()
    if Wnck is None:
        return None
    if not _screen_loaded:
        _screen_loaded = True
        try:
            _screen = Wnck.Screen.get_default()
            if _screen is not None:
                _screen.force_update()
        except Exception:
            _screen = None
    return _screen


def windows():
    """Окна, которые должны попадать в список задач."""
    scr = screen()
    if scr is None:
        return []
    out = []
    try:
        items = scr.get_windows()
    except Exception:
        return []
    for win in items:
        try:
            if win.is_skip_tasklist():
                continue
            if not (win.get_name() or "").strip():
                continue
        except Exception:
            continue
        out.append(win)
    try:
        out.sort(key=lambda w: w.get_xid())
    except Exception:
        pass
    return out


def by_xid(xid):
    """Найти живое окно по XID (или None)."""
    try:
        xid = int(xid)
    except (TypeError, ValueError):
        return None
    for win in windows():
        try:
            if win.get_xid() == xid:
                return win
        except Exception:
            continue
    return None


def active():
    scr = screen()
    if scr is None:
        return None
    try:
        return scr.get_active_window()
    except Exception:
        return None


def geometry(win):
    """(x, y, width, height) окна вместе с рамкой или None."""
    if win is None:
        return None
    try:
        x, y, w, h = win.get_geometry()
        return int(x), int(y), int(w), int(h)
    except Exception:
        return None


def active_app():
    """Активное окно приложения.

    Рабочий стол, панель, док и прочие служебные окна не считаются: иначе
    док/панель прятались бы «сами от себя» и мигали на пустом рабочем столе.
    """
    win = active()
    if win is None:
        return None
    try:
        if win.is_skip_tasklist():
            return None
        if Wnck is not None and win.get_window_type() in (
                Wnck.WindowType.DESKTOP, Wnck.WindowType.DOCK):
            return None
    except Exception:
        return None
    return win


def is_fullscreen(win):
    try:
        return bool(win is not None and win.is_fullscreen())
    except Exception:
        return False


def is_maximized(win):
    try:
        return bool(win is not None and win.is_maximized())
    except Exception:
        return False


def icon_pixbuf(win, size=16):
    """Иконка окна (или приложения), уменьшенная до size×size."""
    if win is None:
        return None
    pb = None
    try:
        pb = win.get_icon()
    except Exception:
        pb = None
    if pb is None:
        try:
            app = win.get_application()
            pb = app.get_icon() if app is not None else None
        except Exception:
            pb = None
    if pb is None:
        return None
    try:
        if pb.get_width() != size or pb.get_height() != size:
            pb = pb.scale_simple(size, size, GdkPixbuf.InterpType.BILINEAR)
    except Exception:
        pass
    return pb
