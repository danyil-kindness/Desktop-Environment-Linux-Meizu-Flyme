# -*- coding: utf-8 -*-
"""Приложения .desktop через GIO."""

import locale
import os
import re

from gi.repository import Gio, Gtk, GdkPixbuf


_ICON_THEME_CACHE = None


def _icon_themes():
    """Текущая тема иконок + надёжные запасные варианты."""
    global _ICON_THEME_CACHE
    if _ICON_THEME_CACHE is not None:
        return _ICON_THEME_CACHE
    themes = [Gtk.IconTheme.get_default()]
    for name in ("Papirus", "Papirus-Dark", "Mint-Y", "Mint-Y-Dark", "Adwaita"):
        try:
            theme = Gtk.IconTheme.new()
            theme.set_custom_theme(name)
            themes.append(theme)
        except Exception:
            pass
    _ICON_THEME_CACHE = themes
    return themes


def load_icon(name, size):
    """Загрузить иконку из текущей/запасной темы, либо None."""
    if not name:
        return None
    flags = Gtk.IconLookupFlags.FORCE_SIZE
    for theme in _icon_themes():
        try:
            return theme.load_icon(name, size, flags)
        except Exception:
            continue
    return None


class App:
    def __init__(self, info):
        self.info = info
        gid = info.get_id() or ""
        self.app_id = gid[:-8] if gid.endswith(".desktop") else gid
        self.name = info.get_display_name() or info.get_name() or self.app_id
        self.comment = info.get_description() or ""
        self.exe = (info.get_executable() or "").strip()
        self._pixbufs = {}
        self._identity = None

    def icon_pixbuf(self, size):
        if size in self._pixbufs:
            return self._pixbufs[size]
        pb = None
        icon = self.info.get_icon()
        try:
            if icon is not None:
                if isinstance(icon, Gio.FileIcon):
                    path = icon.get_file().get_path()
                    if path:
                        pb = GdkPixbuf.Pixbuf.new_from_file_at_size(path, size, size)
                else:
                    names = icon.get_names() if hasattr(icon, "get_names") else []
                    if not names:
                        names = [str(icon)]
                    for name in names:
                        pb = load_icon(name, size)
                        if pb is not None:
                            break
        except Exception:
            pb = None
        if pb is None:
            pb = load_icon("application-x-executable", size)
        self._pixbufs[size] = pb
        return pb

    def launch(self):
        try:
            return self.info.launch_uris([], None)
        except Exception:
            try:
                return Gio.AppInfo.launch(self.info, [], None)
            except Exception:
                return False

    def tokens(self):
        """Токены для эвристического сопоставления окна (без имён и путей)."""
        values = [self.app_id, os.path.basename(self.exe or "")]
        try:
            wmclass = self.info.get_startup_wm_class() or ""
        except Exception:
            wmclass = ""
        if wmclass:
            values.append(wmclass)
        text = " ".join(values).lower().replace("-", " ").replace(".", " ")
        return set(re.findall(r"[a-z0-9]+", text)) - _GENERIC_TOKENS

    def identity(self):
        """Строки, которые могут совпасть с WM_CLASS приложения."""
        if self._identity is not None:
            return self._identity
        ident = set()
        values = [self.app_id, self.app_id.split(".")[-1]]
        if self.exe:
            values.append(os.path.basename(self.exe))
        try:
            swc = self.info.get_startup_wm_class()
        except Exception:
            swc = None
        if swc:
            values.append(swc)
        for value in values:
            value = (value or "").strip().lower()
            if not value:
                continue
            ident.add(value)
            ident.add(re.sub(r"[^a-z0-9]+", " ", value).strip())
        self._identity = {v for v in ident if v}
        return self._identity

    def match_class(self, wm_classes):
        """Оценка близости окна приложению по WM_CLASS (0 = не подходит)."""
        classes = [str(c).strip().lower() for c in (wm_classes or []) if c]
        if not classes:
            return 0
        best = 0
        class_text = " ".join(classes)
        class_words = set(re.findall(r"[a-z0-9]+", class_text)) - _GENERIC_TOKENS
        for ident in self.identity():
            if ident in classes:
                best = max(best, 100)
            elif len(ident) >= 4 and ident in class_text:
                best = max(best, 70)
            elif len(class_text) >= 4 and class_text in ident:
                best = max(best, 50)
        if best == 0:
            # Запасной вариант: редкие слова из идентификатора (например,
            # google-chrome-stable ↔ google-chrome).
            shared = self.tokens() & class_words
            meaningful = {t for t in shared if len(t) >= 4}
            if meaningful:
                best = 20 + 5 * len(meaningful)
        return best

    def matches(self, query):
        if not query:
            return True
        hay = (self.name + " " + self.comment + " " + self.app_id + " " + self.exe)
        hay = hay.lower()
        return all(tok in hay for tok in query.lower().split())


# Слова, которые встречаются в WM_CLASS/идентификаторах слишком часто,
# чтобы служить надёжным признаком приложения.
_GENERIC_TOKENS = {
    "app", "application", "bin", "desktop", "gnome", "gtk", "kde", "linux",
    "org", "com", "net", "python", "python3", "py", "sh", "bash", "usr",
    "local", "share", "lib", "libexec", "x86", "64", "gtk3", "gtk4",
    "stable", "beta", "devel", "default", "main", "start", "run",
}

_SHELL_CLASSES = (
    "flyme-panel", "flyme-dock", "flyme-launcher", "flyme-control-center",
    "flyme-notifications", "flyme-lock", "panel.py", "dock.py",
    "launcher.py", "control_center.py", "control-center.py", "notify.py",
    "lock.py", "flyme-session", "xfdesktop", "xfwm4",
)

_cache = None


def list_apps():
    """Список видимых приложений, отсортированный по имени."""
    global _cache
    if _cache is not None:
        return _cache
    apps = []
    for info in Gio.AppInfo.get_all():
        try:
            if not info.should_show():
                continue
            if info.get_nodisplay():
                continue
        except Exception:
            continue
        apps.append(App(info))
    try:
        apps.sort(key=lambda a: locale.strxfrm(a.name.lower()))
    except Exception:
        apps.sort(key=lambda a: a.name.lower())
    _cache = apps
    return apps


def find(app_id):
    for app in list_apps():
        if app.app_id == app_id:
            return app
    return None


def is_shell_window(wm_classes):
    text = " ".join(str(c) for c in (wm_classes or [])).lower()
    return any(name in text for name in _SHELL_CLASSES)


def running_windows():
    """[(xid, tokens)] по открытым окнам приложений (без панели/дока)."""
    from . import x11  # noqa: PLC0415
    out = []
    try:
        for win in x11.client_list():
            classes = x11.wm_class(win)
            if is_shell_window(classes):
                continue
            out.append((win, x11.tokens_for_window(win)))
    except Exception:
        pass
    return out


def window_candidates():
    """[(xid, wm_classes)] — окна, которые могут принадлежать приложению."""
    from . import x11  # noqa: PLC0415
    out = []
    try:
        for win in x11.client_list():
            classes = x11.wm_class(win)
            if not classes or is_shell_window(classes):
                continue
            out.append((win, classes))
    except Exception:
        pass
    return out


def windows_for(app):
    """Окна, относящиеся к приложению (сначала точное совпадение класса)."""
    hits = []
    for win, classes in window_candidates():
        score = app.match_class(classes)
        if score:
            hits.append((win, score))
    hits.sort(key=lambda t: -t[1])
    return [w for w, _s in hits]


def running_map(app_list=None):
    """{app_id: xid} — первое окно для каждого запущенного приложения."""
    candidates = window_candidates()
    result = {}
    for app in (app_list if app_list is not None else list_apps()):
        best = None
        best_score = 0
        for win, classes in candidates:
            score = app.match_class(classes)
            if score > best_score:
                best, best_score = win, score
        if best is not None and best_score >= 50:
            result[app.app_id] = best
    return result
