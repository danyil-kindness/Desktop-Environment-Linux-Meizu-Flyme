# -*- coding: utf-8 -*-
"""Палитра Flyme и рисование иконок cairo (оригинальная графика, 24×24 сетка)."""

import math

import cairo

from . import config

# Палитры в духе Flyme 9/10: минимализм, синий акцент #0088FF.
PALETTES = {
    "light": {
        "bg": "#F4F6F8",
        "surface": "#FFFFFF",
        "surface2": "#EEF1F5",
        "text": "#17191C",
        "sub": "#8B93A1",
        "accent": "#0088FF",
        "accent_text": "#FFFFFF",
        "border": "#E3E7ED",
        "danger": "#FF3B30",
        "success": "#34C759",
        # RGBA кортежи для cairo (r, g, b) 0..1
        "panel_rgba": (0.965, 0.972, 0.980, 0.82),
        "panel_text": (0.09, 0.10, 0.11),
        "panel_sub": (0.45, 0.48, 0.53),
        "overlay": (0.055, 0.065, 0.085, 0.95),
    },
    "dark": {
        "bg": "#16181C",
        "surface": "#23262B",
        "surface2": "#2A2E34",
        "text": "#F2F3F5",
        "sub": "#9AA1AC",
        "accent": "#0088FF",
        "accent_text": "#FFFFFF",
        "border": "#2E3238",
        "danger": "#FF453A",
        "success": "#30D158",
        "panel_rgba": (0.086, 0.094, 0.11, 0.82),
        "panel_text": (0.93, 0.94, 0.95),
        "panel_sub": (0.60, 0.63, 0.67),
        "overlay": (0.04, 0.045, 0.06, 0.96),
    },
}


def palette():
    return PALETTES["dark"] if config.is_dark() else PALETTES["light"]


def hex_rgba(hex_color, alpha=1.0):
    h = hex_color.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (r / 255.0, g / 255.0, b / 255.0, alpha)


def css_rgba(hex_color, alpha=1.0):
    r, g, b, _a = hex_rgba(hex_color, alpha)
    return "rgba(%d,%d,%d,%.3f)" % (round(r * 255), round(g * 255), round(b * 255), alpha)


# ---------------------------------------------------------------- cairo иконки

def draw(cr, name, color, size, **kw):
    """Нарисовать иконку `name` (сетка 24×24) цветом `color` (hex-строка или
    r,g,b[.a]) в cr."""
    fn = _ICONS.get(name)
    if fn is None:
        fn = _ICONS["grid"]
    if isinstance(color, str):
        color = hex_rgba(color)
    cr.save()
    s = size / 24.0
    cr.scale(s, s)
    if len(color) == 3:
        cr.set_source_rgba(color[0], color[1], color[2], 1.0)
    else:
        cr.set_source_rgba(*color)
    cr.set_line_width(1.9)
    cr.set_line_cap(cairo.LINE_CAP_ROUND)
    cr.set_line_join(cairo.LINE_JOIN_ROUND)
    fn(cr, **kw)
    cr.restore()


def _menu(cr):
    for y in (7.5, 12, 16.5):
        cr.move_to(5, y)
        cr.line_to(19, y)
        cr.stroke()


def _wifi(cr, off=False):
    cx, cy = 12, 16.5
    for r in (3.4, 7.0, 10.6):
        cr.move_to(cx + r * math.cos(math.radians(-135)), cy + r * math.sin(math.radians(-135)))
        cr.arc(cx, cy, r, math.radians(-135), math.radians(-45))
        cr.stroke()
    cr.arc(cx, cy, 1.5, 0, 2 * math.pi)
    cr.fill()
    if off:
        cr.set_line_width(2.2)
        cr.move_to(4.5, 4.5)
        cr.line_to(19.5, 19.5)
        cr.stroke()


def _volume(cr, mute=False):
    cr.move_to(4.5, 9.5)
    cr.line_to(8.5, 9.5)
    cr.line_to(13.5, 5.2)
    cr.line_to(13.5, 18.8)
    cr.line_to(8.5, 14.5)
    cr.line_to(4.5, 14.5)
    cr.close_path()
    cr.fill()
    if mute:
        cr.set_line_width(2.0)
        cr.move_to(16.5, 9.0)
        cr.line_to(21.0, 15.0)
        cr.move_to(21.0, 9.0)
        cr.line_to(16.5, 15.0)
        cr.stroke()
    else:
        cr.arc(13.6, 12, 4.2, math.radians(-52), math.radians(52))
        cr.stroke()
        cr.arc(13.6, 12, 7.6, math.radians(-46), math.radians(46))
        cr.stroke()


def _battery(cr, level=1.0, charging=False):
    level = max(0.0, min(1.0, float(level)))
    cr.set_line_width(1.6)
    _round_rect(cr, 3.5, 8.0, 15.0, 8.0, 2.4)
    cr.stroke()
    _round_rect(cr, 19.2, 10.6, 1.6, 2.8, 0.8)
    cr.fill()
    if level > 0.02:
        w = max(1.6, 12.6 * level)
        _round_rect(cr, 5.0, 9.5, w, 5.0, 1.2)
        cr.fill()
    if charging:
        cr.move_to(13.4, 8.6)
        cr.line_to(10.6, 12.4)
        cr.line_to(12.6, 12.4)
        cr.line_to(11.0, 15.6)
        cr.line_to(14.2, 11.6)
        cr.line_to(12.0, 11.6)
        cr.close_path()
        cr.fill()


def _bell(cr):
    cr.move_to(12, 4.2)
    cr.curve_to(7.8, 4.2, 6.4, 7.6, 6.4, 10.8)
    cr.curve_to(6.4, 14.4, 4.9, 15.6, 4.9, 16.4)
    cr.line_to(19.1, 16.4)
    cr.curve_to(19.1, 15.6, 17.6, 14.4, 17.6, 10.8)
    cr.curve_to(17.6, 7.6, 16.2, 4.2, 12, 4.2)
    cr.close_path()
    cr.fill()
    cr.move_to(10.2, 18.6)
    cr.curve_to(10.2, 20.4, 13.8, 20.4, 13.8, 18.6)
    cr.close_path()
    cr.fill()


def _moon(cr):
    # полумесяц: внешняя дуга слева + вогнутая дуга обратно
    cr.arc(12, 12, 7.8, math.radians(55), math.radians(305))
    cr.arc_negative(15.4, 12, 6.8, math.radians(300), math.radians(60))
    cr.close_path()
    cr.fill()


def _sun(cr):
    cr.arc(12, 12, 4.4, 0, 2 * math.pi)
    cr.fill()
    for i in range(8):
        a = math.radians(i * 45)
        x1, y1 = 12 + 7.2 * math.cos(a), 12 + 7.2 * math.sin(a)
        x2, y2 = 12 + 9.8 * math.cos(a), 12 + 9.8 * math.sin(a)
        cr.move_to(x1, y1)
        cr.line_to(x2, y2)
        cr.stroke()


def _bluetooth(cr):
    cr.move_to(7, 7.5)
    cr.line_to(16.5, 16.0)
    cr.line_to(12, 20.0)
    cr.line_to(12, 4.0)
    cr.line_to(16.5, 8.0)
    cr.line_to(7, 16.5)
    cr.close_path()
    cr.stroke()


def _lock(cr):
    cr.set_line_width(1.9)
    cr.arc(12, 10.2, 4.0, math.radians(180), 0)
    cr.stroke()
    _round_rect(cr, 5.2, 10.2, 13.6, 9.2, 2.4)
    cr.fill()


def _search(cr):
    cr.arc(10.6, 10.6, 6.0, 0, 2 * math.pi)
    cr.stroke()
    cr.move_to(15.0, 15.0)
    cr.line_to(20.0, 20.0)
    cr.stroke()


def _power(cr):
    cr.set_line_width(2.1)
    cr.arc(12, 12, 7.2, math.radians(-60), math.radians(240))
    cr.stroke()
    cr.move_to(12, 3.2)
    cr.line_to(12, 11.0)
    cr.stroke()


def _restart(cr):
    cr.set_line_width(2.0)
    cr.arc(12, 12, 7.0, math.radians(-40), math.radians(200))
    cr.stroke()
    cr.move_to(4.0, 8.0)
    cr.line_to(5.2, 13.6)
    cr.line_to(10.4, 11.2)
    cr.close_path()
    cr.fill()


def _gear(cr):
    cr.arc(12, 12, 3.4, 0, 2 * math.pi)
    cr.fill()
    cr.set_line_width(2.4)
    for i in range(8):
        a = math.radians(i * 45)
        x1, y1 = 12 + 5.6 * math.cos(a), 12 + 5.6 * math.sin(a)
        x2, y2 = 12 + 9.6 * math.cos(a), 12 + 9.6 * math.sin(a)
        cr.move_to(x1, y1)
        cr.line_to(x2, y2)
        cr.stroke()
    cr.set_line_width(1.6)
    cr.arc(12, 12, 8.6, 0, 2 * math.pi)
    cr.stroke()


def _chevron(cr):
    cr.set_line_width(2.1)
    cr.move_to(9.5, 5.5)
    cr.line_to(16.5, 12)
    cr.line_to(9.5, 18.5)
    cr.stroke()


def _close(cr):
    cr.set_line_width(2.0)
    cr.move_to(6.5, 6.5)
    cr.line_to(17.5, 17.5)
    cr.move_to(17.5, 6.5)
    cr.line_to(6.5, 17.5)
    cr.stroke()


def _grid(cr):
    for x in (6.0, 12.0, 18.0):
        for y in (6.0, 12.0, 18.0):
            cr.arc(x, y, 1.9, 0, 2 * math.pi)
            cr.fill()


def _contrast(cr):
    cr.set_line_width(1.8)
    cr.arc(12, 12, 7.8, 0, 2 * math.pi)
    cr.stroke()
    cr.save()
    cr.arc(12, 12, 7.8, math.radians(90), math.radians(270))
    cr.close_path()
    cr.fill()
    cr.restore()


def _user(cr):
    cr.arc(12, 8.4, 4.0, 0, 2 * math.pi)
    cr.fill()
    cr.move_to(4.6, 20.4)
    cr.curve_to(4.6, 15.2, 19.4, 15.2, 19.4, 20.4)
    cr.close_path()
    cr.fill()


def _round_rect(cr, x, y, w, h, r):
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, math.radians(-90), 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.radians(90))
    cr.arc(x + r, y + h - r, r, math.radians(90), math.radians(180))
    cr.arc(x + r, y + r, r, math.radians(180), math.radians(270))
    cr.close_path()


def _dot(cr):
    cr.arc(12, 12, 8.0, 0, 2 * math.pi)
    cr.fill()


_ICONS = {
    "menu": _menu,
    "wifi": _wifi,
    "wifi-off": lambda cr: _wifi(cr, off=True),
    "volume": _volume,
    "volume-mute": lambda cr: _volume(cr, mute=True),
    "battery": _battery,
    "bell": _bell,
    "moon": _moon,
    "sun": _sun,
    "bluetooth": _bluetooth,
    "lock": _lock,
    "search": _search,
    "power": _power,
    "restart": _restart,
    "gear": _gear,
    "chevron": _chevron,
    "close": _close,
    "grid": _grid,
    "contrast": _contrast,
    "user": _user,
    "dot": _dot,
}
