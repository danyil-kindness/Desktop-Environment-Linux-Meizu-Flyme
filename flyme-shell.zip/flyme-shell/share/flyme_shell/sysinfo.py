# -*- coding: utf-8 -*-
"""Доступ к системным параметрам ноутбука с безопасными фолбэками."""

import os
import re
import shlex
import shutil
import subprocess

from .i18n import _

_TIMEOUT = 4


def _run(args, timeout=_TIMEOUT):
    try:
        return subprocess.run(
            args, capture_output=True, text=True, timeout=timeout, check=False
        )
    except Exception:
        return None


def which(name):
    return shutil.which(name)


# ------------------------------------------------------------- батарея (ноут)

def battery():
    """-> (процент 0..100, заряжается bool) либо None (нет батареи)."""
    base = "/sys/class/power_supply"
    try:
        entries = os.listdir(base)
    except OSError:
        return None
    for name in entries:
        path = os.path.join(base, name)
        try:
            with open(os.path.join(path, "type"), encoding="ascii") as fh:
                if fh.read().strip() != "Battery":
                    continue
            with open(os.path.join(path, "capacity"), encoding="ascii") as fh:
                cap = int(fh.read().strip())
            status = ""
            try:
                with open(os.path.join(path, "status"), encoding="ascii") as fh:
                    status = fh.read().strip()
            except OSError:
                pass
            return cap, status in ("Charging", "Full", "Not charging")
        except (OSError, ValueError):
            continue
    return None


# -------------------------------------------------------------------- звук

def get_volume():
    if which("pactl"):
        res = _run(["pactl", "get-sink-volume", "@DEFAULT_SINK@"])
        if res and res.stdout:
            m = re.search(r"(\d+)\s*%", res.stdout)
            if m:
                return int(m.group(1))
    if which("amixer"):
        res = _run(["amixer", "get", "Master"])
        if res and res.stdout:
            vals = re.findall(r"\[(\d+)%\]", res.stdout)
            if vals:
                return int(vals[-1])
    return None


def set_volume(pct):
    pct = max(0, min(150, int(pct)))
    if which("pactl"):
        if _run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", "%d%%" % pct]):
            return True
    if which("amixer"):
        _run(["amixer", "set", "Master", "%d%%" % pct])
        return True
    return False


def get_mute():
    if which("pactl"):
        res = _run(["pactl", "get-sink-mute", "@DEFAULT_SINK@"])
        if res and res.stdout:
            return "yes" in res.stdout.lower()
    if which("amixer"):
        res = _run(["amixer", "get", "Master"])
        if res and res.stdout:
            vals = re.findall(r"\[(on|off)\]", res.stdout)
            if vals:
                return vals[-1] == "off"
    return False


def toggle_mute():
    if which("pactl"):
        _run(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "toggle"])
        return True
    if which("amixer"):
        _run(["amixer", "set", "Master", "toggle"])
        return True
    return False


# ----------------------------------------------------------------- яркость

def get_brightness():
    if which("brightnessctl"):
        res = _run(["brightnessctl", "-m"])
        if res and res.stdout:
            parts = res.stdout.strip().split(",")
            if len(parts) >= 4 and parts[3].endswith("%"):
                try:
                    return int(parts[3].rstrip("%"))
                except ValueError:
                    pass
        res = _run(["brightnessctl", "-g"])
        if res and res.stdout.strip().isdigit():
            res2 = _run(["brightnessctl", "-m"])  # max недоступен — оценить нельзя
            _ = res2
    if which("xbacklight"):
        res = _run(["xbacklight", "-get"])
        if res and res.stdout.strip():
            try:
                return int(float(res.stdout.strip()))
            except ValueError:
                pass
    return None


def set_brightness(pct):
    pct = max(1, min(100, int(pct)))
    if which("brightnessctl"):
        _run(["brightnessctl", "set", "%d%%" % pct])
        return True
    if which("xbacklight"):
        _run(["xbacklight", "-set", str(pct)])
        return True
    return False


# ------------------------------------------------------------------- сеть

def wifi_enabled():
    if which("nmcli"):
        res = _run(["nmcli", "-t", "radio", "wifi"])
        if res and res.stdout:
            return res.stdout.strip() == "enabled"
    return None


def set_wifi(on):
    if which("nmcli"):
        _run(["nmcli", "radio", "wifi", "on" if on else "off"])
        return True
    return False


# ------------------------------------------------------------- питание

def _spawn_power(args):
    try:
        subprocess.Popen(args, start_new_session=True)
        return True
    except Exception:
        return False


def poweroff():
    return _spawn_power(["systemctl", "poweroff"])


def reboot():
    return _spawn_power(["systemctl", "reboot"])


def lock_screen():
    """Заблокировать экран командой из ~/.config/flyme-shell/config.ini."""
    from . import config  # noqa: PLC0415
    cmd = config.get("lock", "command", "flyme-lock").strip() or "flyme-lock"
    return _spawn_power(shlex.split(cmd))


def logout():
    """Завершить графический сеанс (systemd-logind, иначе Xfce)."""
    session = os.environ.get("XDG_SESSION_ID", "")
    if session and which("loginctl"):
        return _spawn_power(["loginctl", "terminate-session", session])
    return _spawn_power(["xfce4-session-logout", "--logout"])


# -------------------------------------------------------------- bluetooth

def bt_powered():
    if which("bluetoothctl"):
        res = _run(["bluetoothctl", "show"])
        if res and res.stdout:
            m = re.search(r"Powered:\s*(\w+)", res.stdout)
            if m:
                return m.group(1) == "yes"
    return None


def set_bt(on):
    if which("bluetoothctl"):
        _run(["bluetoothctl", "power", "on" if on else "off"])
        return True
    return False


# --------------------------------------------------- сети Wi-Fi (nmcli)

def _split_nmcli(line):
    r"""Разобрать строку nmcli -t с экранированием \: и \\."""
    out, cur, esc = [], [], False
    for ch in line:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            out.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    out.append("".join(cur))
    return out


def _wifi_device():
    if not which("nmcli"):
        return None
    res = _run([ "nmcli", "-t", "-f", "DEVICE,TYPE", "device"])
    for line in (res.stdout or "").splitlines() if res else ():
        parts = _split_nmcli(line)
        if len(parts) >= 2 and parts[1] == "wifi":
            return parts[0]
    return None


def wifi_current():
    """SSID активной сети или ''."""
    if not which("nmcli"):
        return ""
    res = _run(["nmcli", "-t", "-f", "IN-USE,SSID", "device", "wifi", "list"])
    for line in (res.stdout or "").splitlines() if res else ():
        parts = _split_nmcli(line)
        if len(parts) >= 2 and parts[0].strip() == "*":
            return parts[1]
    return ""


def wifi_networks(rescan=True):
    """[(ssid, signal, security, in_use)] — по убыванию сигнала."""
    if not which("nmcli"):
        return []
    args = ["nmcli", "-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY",
            "device", "wifi", "list"]
    if rescan:
        args += ["--rescan", "yes"]
    res = _run(args, timeout=25)
    seen = {}
    for line in (res.stdout or "").splitlines() if res else ():
        parts = _split_nmcli(line)
        if len(parts) < 4:
            continue
        in_use, ssid, sig, sec = parts[0], parts[1], parts[2], parts[3]
        ssid = ssid.strip()
        if not ssid:
            continue
        try:
            sig_i = int(sig)
        except ValueError:
            sig_i = 0
        used = in_use.strip() == "*"
        old = seen.get(ssid)
        if old is None or used or sig_i > old[1]:
            seen[ssid] = (ssid, sig_i,
                          "" if sec.strip() in ("", "--") else sec.strip(),
                          used)
    return sorted(seen.values(), key=lambda n: (not n[3], -n[1], n[0].lower()))


def wifi_saved_names():
    """Множество имён сохранённых Wi-Fi профилей."""
    if not which("nmcli"):
        return set()
    res = _run(["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"])
    names = set()
    for line in (res.stdout or "").splitlines() if res else ():
        parts = _split_nmcli(line)
        if len(parts) >= 2 and "wireless" in parts[1].lower():
            names.add(parts[0])
    return names


def wifi_saved(ssid):
    """Есть ли сохранённый профиль для этой сети."""
    return ssid in wifi_saved_names()


def wifi_connect(ssid, password=None):
    """-> (ok, сообщение). Подключается к сети, при необходимости с паролем."""
    if not which("nmcli"):
        return False, _("nmcli не найден")
    args = ["nmcli", "--wait", "30", "device", "wifi", "connect", ssid]
    if password:
        args += ["password", password]
    res = _run(args, timeout=45)
    if res is None:
        return False, _("истекло время ожидания")
    text = ((res.stdout or "") + (res.stderr or "")).strip()
    return res.returncode == 0, text


def wifi_disconnect():
    if not which("nmcli"):
        return False
    dev = _wifi_device()
    if not dev:
        return False
    res = _run(["nmcli", "device", "disconnect", dev], timeout=20)
    return bool(res and res.returncode == 0)


# ------------------------------------------------------------- bluetooth

def _bt_macs(args):
    res = _run(args, timeout=8)
    macs = set()
    for line in (res.stdout or "").splitlines() if res else ():
        parts = line.strip().split(" ", 2)
        if len(parts) >= 2 and parts[0] == "Device":
            macs.add(parts[1])
    return macs


def bt_devices():
    """[(mac, name, connected, paired)] известных устройств."""
    if not which("bluetoothctl"):
        return []
    res = _run(["bluetoothctl", "devices"], timeout=8)
    out = []
    for line in (res.stdout or "").splitlines() if res else ():
        parts = line.strip().split(" ", 2)
        if len(parts) < 2 or parts[0] != "Device":
            continue
        mac = parts[1]
        name = parts[2].strip() if len(parts) > 2 else mac
        out.append([mac, name])
    if not out:
        return []
    connected = _bt_macs(["bluetoothctl", "devices", "Connected"])
    paired = _bt_macs(["bluetoothctl", "devices", "Paired"])
    return [(mac, name, mac in connected, mac in paired) for mac, name in out]


def bt_scan(seconds=10):
    """Поиск новых устройств (блокирует на seconds секунд)."""
    if not which("bluetoothctl"):
        return False
    _run(["bluetoothctl", "--timeout", str(int(seconds)), "scan", "on"],
         timeout=int(seconds) + 8)
    return True


def bt_connect(mac):
    """-> (ok, сообщение)."""
    if not which("bluetoothctl"):
        return False, _("bluetoothctl не найден")
    if mac in _bt_macs(["bluetoothctl", "devices", "Paired"]):
        _run(["bluetoothctl", "connect", mac], timeout=30)
    else:
        _run(["bluetoothctl", "pair", mac], timeout=30)
        _run(["bluetoothctl", "trust", mac], timeout=10)
        _run(["bluetoothctl", "connect", mac], timeout=30)
    ok = mac in _bt_macs(["bluetoothctl", "devices", "Connected"])
    return ok, "" if ok else _("не удалось подключиться")


def bt_disconnect(mac):
    if not which("bluetoothctl"):
        return False
    _run(["bluetoothctl", "disconnect", mac], timeout=15)
    return True
