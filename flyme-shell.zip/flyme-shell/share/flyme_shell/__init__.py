# -*- coding: utf-8 -*-
"""Flyme Shell — нативная GTK3-оболочка в стиле Meizu Flyme для Xfce/Mint."""

import gi

gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")

__version__ = "1.0.0"
APP_NAME = "flyme-shell"
