# -*- coding: utf-8 -*-
"""Центр управления Flyme: быстрые переключатели, громкость, яркость."""

import subprocess
import threading

from gi.repository import Gdk, Gio, GLib, Gtk, Pango

from . import config, i18n, sysinfo, theme, widgets
from .i18n import _

WIDTH = 404


def _spawn(cmd):
    try:
        subprocess.Popen(cmd, start_new_session=True)
    except Exception:
        pass


class ControlCenterApp(widgets.ShellApp):
    def __init__(self):
        super().__init__("org.flyme.ControlCenter")
        self.win = None

    def do_activate(self):
        if self.win is None:
            self.win = self.track(ControlCenterWindow(self))
        self.win.toggle()

    def rebuild(self):
        """Пересоздать окно (после смены языка интерфейса)."""
        old = self.win
        self.win = self.track(ControlCenterWindow(self))
        i18n.mark_started()
        if old is not None:
            old.hide()
            old.destroy()
        self.win.toggle()


class ControlCenterWindow(widgets.ThemedWindow):
    # язык меняется прямо из этого окна — пересобираем его, а не процесс
    relaunch_on_language = False

    def __init__(self, app):
        super().__init__()
        self.app = app
        self._lang_busy = False
        self.set_title(_("Центр управления"))
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_decorated(False)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_accept_focus(True)
        widgets.set_rgba(self)

        self.css_prov = widgets.css_provider(self.build_css())
        self.use_css(self.css_prov)

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        card.set_margin_top(16)
        card.set_margin_bottom(16)
        card.set_margin_start(18)
        card.set_margin_end(18)
        card.get_style_context().add_class("flyme-card")
        # клики по «карточке» не закрывают окно — только Esc или фон
        card.connect("button-press-event", lambda *_: True)

        # заголовок
        header = Gtk.Label()
        header.set_markup(_("<b>Центр управления</b>"))
        header.set_halign(Gtk.Align.START)
        header.get_style_context().add_class("flyme-header")
        card.pack_start(header, False, False, 0)

        # плитки быстрых настроек
        self.tiles = {}
        grid = Gtk.Grid()
        grid.set_row_spacing(10)
        grid.set_column_spacing(10)
        tile_defs = [
            ("wifi", "Wi-Fi", "wifi"),
            ("bt", "Bluetooth", "bluetooth"),
            ("dark", _("Тёмная тема"), "contrast"),
            ("dnd", _("Не беспокоить"), "moon"),
        ]
        for i, (key, label, icon) in enumerate(tile_defs):
            tile = self._make_tile(label, icon)
            tile.connect("button-press-event", self._on_tile, key)
            grid.attach(tile, i % 4, 0, 1, 1)
            self.tiles[key] = tile
        card.pack_start(grid, False, False, 0)

        # списки сетей (Wi-Fi / Bluetooth)
        self.net_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        card.pack_start(self.net_box, False, False, 0)
        self._wifi_on = False
        self._bt_on = False
        self._wifi_loading = False
        self._bt_loading = False
        self._wifi_nets = []
        self._wifi_saved = set()
        self._wifi_msg = ""
        self._pw_ssid = None
        self._pw_error = ""
        self._bt_items = []
        self._bt_msg = ""
        self._net_busy = ""

        # ползунки
        self.bright_box, self.bright_scale = self._make_scale("sun", _("Яркость"))
        self.bright_scale.connect("value-changed", self._on_bright)
        card.pack_start(self.bright_box, False, False, 0)

        self.vol_box, self.vol_scale = self._make_scale("volume", _("Громкость"))
        self.vol_scale.connect("value-changed", self._on_vol)
        card.pack_start(self.vol_box, False, False, 0)

        self.state_label = Gtk.Label()
        self.state_label.set_halign(Gtk.Align.START)
        self.state_label.get_style_context().add_class("flyme-sub")
        card.pack_start(self.state_label, False, False, 0)

        # выбор языка интерфейса
        card.pack_start(self._make_language_box(), False, False, 0)

        # кнопки действий
        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn_settings = self._make_action("gear", _("Настройки"), self._open_settings)
        btn_lock = self._make_action("lock", _("Заблокировать"),
                                     lambda *_: sysinfo.lock_screen())
        btn_power = self._make_action("power", _("Питание"), self._power_menu)
        actions.pack_start(btn_settings, True, True, 0)
        actions.pack_start(btn_lock, True, True, 0)
        actions.pack_start(btn_power, True, True, 0)
        card.pack_start(actions, False, False, 0)

        self.add(card)
        self.get_style_context().add_class("flyme-cc")
        self.connect("button-press-event", self._on_bg_press)
        self.connect("key-press-event", self._on_key)

        self._suppress = False
        self.show_all()
        self.hide()
        self._position()

    # ---------------------------------------------------------------- тема

    def build_css(self):
        pal = theme.palette()
        return """
            window.flyme-cc {{
                background-color: transparent;
            }}
            .flyme-card {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 18px;
                color: {text};
            }}
            .flyme-header {{ font-size: 15px; color: {text}; }}
            .flyme-sub {{ color: {sub}; font-size: 11px; }}
            .flyme-tile {{
                background-color: {surface2};
                border: none;
                border-radius: 16px;
                padding: 12px 6px;
                min-width: 82px;
                color: {text};
            }}
            .flyme-tile:hover {{ background-color: {border}; }}
            .flyme-tile-active {{
                background-color: {accent};
                color: {accent_text};
            }}
            .flyme-tile-active:hover {{
                background-color: {accent};
                opacity: 0.9;
            }}
            .flyme-action {{
                background-color: {surface2};
                border: none;
                border-radius: 12px;
                padding: 10px 6px;
                color: {text};
                font-size: 12px;
            }}
            .flyme-action:hover {{ background-color: {border}; }}
            .flyme-netrow {{
                background: transparent;
                border: none;
                border-radius: 10px;
                padding: 6px 8px;
                color: {text};
                font-size: 12.5px;
            }}
            .flyme-netrow:hover {{ background-color: {surface2}; }}
            .flyme-netrow-active {{ background-color: {surface2}; }}
            .flyme-netrow label {{ color: {text}; }}
            .flyme-netrow .flyme-sub {{ color: {sub}; font-size: 11px; }}
            .flyme-iconbtn {{
                background: transparent;
                border: none;
                padding: 2px 4px;
                border-radius: 8px;
            }}
            .flyme-iconbtn:hover {{ background-color: {surface2}; }}
            .flyme-pwbox {{
                background-color: {surface2};
                border-radius: 10px;
                padding: 6px;
            }}
            .flyme-pwbox entry {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 8px;
                padding: 4px 8px;
                color: {text};
                font-size: 12px;
            }}
            .flyme-btn {{
                background-color: {accent};
                border: none;
                border-radius: 8px;
                padding: 5px 12px;
                color: {accent_text};
                font-size: 12px;
            }}
            .flyme-language {{
                background-color: {surface2};
                border-radius: 10px;
                padding: 5px 4px;
                color: {text};
                font-size: 11.5px;
            }}
            .flyme-language:hover {{ background-color: {border}; }}
            .flyme-language.flyme-language-active,
            .flyme-language.flyme-language-active:hover {{
                background-color: {accent};
                color: {accent_text};
                font-weight: bold;
            }}
            .flyme-err {{ color: #e05252; font-size: 11px; }}
            .flyme-ok {{ color: {sub}; font-size: 11px; }}
            scale trough {{
                background-color: {surface2};
                border-radius: 4px;
                min-height: 8px;
            }}
            scale highlight {{
                background-color: {accent};
                border-radius: 4px;
            }}
            scale slider {{
                background-color: {surface};
                border: 2px solid {accent};
                border-radius: 16px;
                min-width: 18px; min-height: 18px;
            }}
        """.format(**pal)

    def apply_theme(self):
        widgets.update_provider(self.css_prov, self.build_css())

    # -------------------------------------------------------------- элементы

    def _make_tile(self, label, icon):
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        area = widgets.IconArea(icon, (1, 1, 1), 22)
        area.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(area, False, False, 0)
        lbl = Gtk.Label(label=label)
        lbl.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(lbl, False, False, 0)
        btn.add(vbox)
        btn.get_style_context().add_class("flyme-tile")
        btn.tile_icon = area
        btn.tile_label = lbl
        return btn

    def _make_scale(self, icon, tooltip):
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        area = widgets.IconArea(icon, theme.hex_rgba(theme.palette()["sub"])[:3], 20)
        box.pack_start(area, False, False, 0)
        scale = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
        scale.set_range(0, 100)
        scale.set_draw_value(False)
        scale.set_hexpand(True)
        scale.set_tooltip_text(tooltip)
        box.pack_start(scale, True, True, 0)
        box.get_style_context().add_class("flyme-sliderbox")
        return box, scale

    def _make_action(self, icon, label, cb):
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        area = widgets.IconArea(icon, theme.hex_rgba(theme.palette()["text"])[:3], 20)
        area.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(area, False, False, 0)
        lbl = Gtk.Label(label=label)
        lbl.set_halign(Gtk.Align.CENTER)
        vbox.pack_start(lbl, False, False, 0)
        btn.add(vbox)
        btn.get_style_context().add_class("flyme-action")
        btn.connect("clicked", cb)
        return btn

    # ------------------------------------------------------------- язык

    def _make_language_box(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)

        lbl = Gtk.Label(label=_("Язык"), xalign=0)
        lbl.get_style_context().add_class("flyme-sub")
        box.pack_start(lbl, False, False, 0)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        row.set_homogeneous(True)
        active = i18n.current()
        for code in i18n.LANGUAGES:
            btn = Gtk.Button(label=i18n.NAMES[code])
            btn.set_relief(Gtk.ReliefStyle.NONE)
            btn.set_can_focus(False)
            ctx = btn.get_style_context()
            ctx.add_class("flyme-language")
            if code == active:
                ctx.add_class("flyme-language-active")
            btn.connect("clicked", lambda _b, c=code: self._pick_language(c))
            row.pack_start(btn, True, True, 0)
        box.pack_start(row, False, False, 0)

        self.auto_check = Gtk.CheckButton(label=_("Как в системе"))
        self.auto_check.get_style_context().add_class("flyme-sub")
        self.auto_check.set_active(i18n.configured() == "auto")
        self.auto_check.connect("toggled", self._on_auto_language)
        box.pack_start(self.auto_check, False, False, 0)
        return box

    def _pick_language(self, code):
        if self._lang_busy:
            return
        self._lang_busy = True
        try:
            if self.auto_check.get_active():
                self.auto_check.set_active(False)
        finally:
            self._lang_busy = False
        config.set_option("general", "language", code)
        self._apply_language()

    def _on_auto_language(self, check):
        if self._lang_busy:
            return
        self._lang_busy = True
        try:
            if check.get_active():
                config.set_option("general", "language", "auto")
            else:
                config.set_option("general", "language", i18n.current())
        finally:
            self._lang_busy = False
        self._apply_language()

    def _apply_language(self):
        i18n.reload()
        self.app.rebuild()

    # ------------------------------------------------------------ сети
    # Wi-Fi: список сетей, ввод пароля, подключение/отключение.
    # Bluetooth: известные устройства, поиск, подключение.

    def _net_section(self, title, refresh_cb):
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        lbl = Gtk.Label(label=title, xalign=0)
        lbl.get_style_context().add_class("flyme-sub")
        head.pack_start(lbl, True, True, 0)
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        btn.get_style_context().add_class("flyme-iconbtn")
        btn.add(widgets.IconArea("search",
                                 theme.hex_rgba(theme.palette()["sub"])[:3], 14))
        btn.set_tooltip_text(_("Обновить список"))
        btn.connect("clicked", lambda *_: refresh_cb())
        head.pack_end(btn, False, False, 0)
        return head

    def _net_scroll(self, body, rows, row_h=40, max_h=190):
        sw = Gtk.ScrolledWindow()
        sw.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sw.set_overlay_scrolling(False)
        sw.get_style_context().add_class("flyme-netscroll")
        try:
            sw.set_propagate_natural_height(True)
            sw.set_min_content_height(row_h)
            sw.set_max_content_height(min(row_h * max(rows, 1), max_h))
        except Exception:
            sw.set_size_request(-1, min(row_h * max(rows, 1), max_h))
        sw.add(body)
        return sw

    def _rebuild_nets(self):
        for child in list(self.net_box.get_children()):
            self.net_box.remove(child)

        if self._wifi_on:
            self.net_box.pack_start(
                self._net_section(_("Сети Wi-Fi"), self._reload_wifi),
                False, False, 0)
            self.net_box.pack_start(self._build_wifi_body(), False, False, 0)
        elif self._wifi_on is False:
            lbl = Gtk.Label(label=_("Wi-Fi выключен — нажмите плитку выше"),
                            xalign=0)
            lbl.get_style_context().add_class("flyme-sub")
            self.net_box.pack_start(lbl, False, False, 0)

        if self._bt_on:
            self.net_box.pack_start(
                self._net_section(_("Устройства Bluetooth"), self._bt_scan),
                False, False, 0)
            self.net_box.pack_start(self._build_bt_body(), False, False, 0)

        self.net_box.show_all()
        GLib.idle_add(self._position)

    # -------------------------------------------------------------- Wi-Fi

    def _reload_wifi(self, *_a):
        if not self._wifi_on or self._wifi_loading:
            return
        self._wifi_loading = True
        self._wifi_msg = _("Поиск сетей…")
        self._rebuild_nets()

        def work():
            nets = sysinfo.wifi_networks()
            saved = sysinfo.wifi_saved_names()
            GLib.idle_add(self._fill_wifi, nets, saved)

        threading.Thread(target=work, daemon=True).start()

    def _fill_wifi(self, nets, saved):
        self._wifi_loading = False
        self._wifi_nets = nets
        self._wifi_saved = saved
        self._wifi_msg = "" if nets else _("Сети не найдены")
        if self._pw_ssid and self._pw_ssid not in [n[0] for n in nets]:
            self._pw_ssid = None
        self._rebuild_nets()

    def _build_wifi_body(self):
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        if self._wifi_msg:
            lbl = Gtk.Label(label=self._wifi_msg, xalign=0)
            lbl.set_line_wrap(True)
            lbl.get_style_context().add_class("flyme-ok")
            body.pack_start(lbl, False, False, 0)
        if not self._wifi_nets:
            if not self._wifi_msg:
                lbl = Gtk.Label(label=_("Поиск сетей…"), xalign=0)
                lbl.get_style_context().add_class("flyme-sub")
                body.pack_start(lbl, False, False, 0)
            return self._net_scroll(body, 1)
        for ssid, sig, sec, used in self._wifi_nets:
            body.pack_start(self._wifi_row(ssid, sig, sec, used), False, False, 0)
            if ssid == self._pw_ssid:
                body.pack_start(self._password_box(ssid), False, False, 0)
        return self._net_scroll(body, len(self._wifi_nets))

    def _wifi_row(self, ssid, signal, security, used):
        pal = theme.palette()
        sub = theme.hex_rgba(pal["sub"])[:3]
        accent = theme.hex_rgba(pal["accent"])[:3]

        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        ctx = btn.get_style_context()
        ctx.add_class("flyme-netrow")
        if used:
            ctx.add_class("flyme-netrow-active")

        hb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hb.pack_start(widgets.IconArea("wifi", accent if used else sub, 16),
                      False, False, 0)
        name = Gtk.Label(label=ssid, xalign=0)
        name.set_ellipsize(Pango.EllipsizeMode.END)
        hb.pack_start(name, True, True, 0)
        if used:
            lbl = Gtk.Label(label=_("подключено"))
            lbl.get_style_context().add_class("flyme-sub")
            hb.pack_end(lbl, False, False, 0)
        elif security:
            hb.pack_end(widgets.IconArea("lock", sub, 13), False, False, 0)
        btn.add(hb)

        if used:
            btn.set_tooltip_text(_("Отключиться от сети"))
            btn.connect("clicked", lambda *_: self._wifi_disconnect())
        elif security and ssid not in self._wifi_saved:
            btn.set_tooltip_text(_("Ввести пароль"))
            btn.connect("clicked", lambda *_: self._ask_password(ssid))
        else:
            btn.connect("clicked", lambda *_: self._connect_wifi(ssid))
        return btn

    def _ask_password(self, ssid):
        self._pw_ssid = ssid
        self._pw_error = ""
        self._rebuild_nets()

    def _password_box(self, ssid):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        box.get_style_context().add_class("flyme-pwbox")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        entry = Gtk.Entry()
        entry.set_visibility(False)
        entry.set_placeholder_text(_("Пароль сети «%s»") % ssid)
        entry.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        entry.set_hexpand(True)
        ok = Gtk.Button(label=_("Подключиться"))
        ok.set_relief(Gtk.ReliefStyle.NONE)
        ok.set_can_focus(False)
        ok.get_style_context().add_class("flyme-btn")
        show = Gtk.CheckButton(label=_("Показать пароль"))
        show.get_style_context().add_class("flyme-sub")
        show.connect("toggled", lambda c: entry.set_visibility(c.get_active()))
        err = Gtk.Label(label=self._pw_error, xalign=0)
        err.set_line_wrap(True)
        err.get_style_context().add_class("flyme-err" if self._pw_error
                                         else "flyme-ok")

        def submit(*_a):
            pwd = entry.get_text()
            ok.set_sensitive(False)
            err.get_style_context().remove_class("flyme-ok")
            err.get_style_context().add_class("flyme-err")
            err.set_text(_("Подключение…"))
            entry.set_sensitive(False)

            def work():
                good, msg = sysinfo.wifi_connect(ssid, pwd or None)
                GLib.idle_add(self._after_connect, good, msg, ssid)

            threading.Thread(target=work, daemon=True).start()

        ok.connect("clicked", submit)
        entry.connect("activate", submit)
        row.pack_start(entry, True, True, 0)
        row.pack_start(ok, False, False, 0)
        box.pack_start(row, False, False, 0)
        box.pack_start(show, False, False, 0)
        if self._pw_error:
            box.pack_start(err, False, False, 0)
        GLib.idle_add(lambda: (entry.grab_focus(), False)[1])
        return box

    def _connect_wifi(self, ssid):
        self._wifi_loading = True
        self._wifi_msg = _("Подключение к «%s»…") % ssid
        self._rebuild_nets()

        def work():
            good, msg = sysinfo.wifi_connect(ssid, None)
            GLib.idle_add(self._after_connect, good, msg, ssid)

        threading.Thread(target=work, daemon=True).start()

    def _after_connect(self, good, msg, ssid):
        self._wifi_loading = False
        if good:
            self._pw_ssid = None
            self._pw_error = ""
            self._wifi_msg = ""
            GLib.timeout_add(600, self._refresh)
            self._reload_wifi()
            return
        error = self._friendly_error(msg)
        self._wifi_msg = _("Не удалось: %s") % error
        self._pw_error = error if self._pw_ssid else ""
        self._rebuild_nets()

    @staticmethod
    def _friendly_error(msg):
        low = (msg or "").lower()
        if "secret" in low or "password" in low or "psk" in low:
            return _("Неверный пароль")
        if "no network with ssid" in low or "not found" in low:
            return _("Сеть не найдена")
        if "timeout" in low or "timed out" in low:
            return _("Истекло время ожидания")
        text = (msg or "").strip().splitlines()
        text = text[-1] if text else _("Не удалось подключиться")
        return text[:120]

    def _wifi_disconnect(self):
        self._wifi_loading = True
        self._wifi_msg = _("Отключение…")
        self._rebuild_nets()
        threading.Thread(target=self._disconnect_work, daemon=True).start()

    def _disconnect_work(self):
        sysinfo.wifi_disconnect()
        nets = sysinfo.wifi_networks()
        saved = sysinfo.wifi_saved_names()
        GLib.idle_add(self._fill_wifi, nets, saved)

    # ------------------------------------------------------------ Bluetooth

    def _load_bt(self):
        if not self._bt_on:
            return
        self._bt_msg = _("Поиск устройств…")

        def work():
            devs = sysinfo.bt_devices()
            GLib.idle_add(self._fill_bt, devs)

        threading.Thread(target=work, daemon=True).start()

    def _bt_scan(self, *_a):
        if not self._bt_on or self._bt_loading:
            return
        self._bt_loading = True
        self._bt_msg = _("Поиск устройств… (10 секунд)")
        self._rebuild_nets()

        def work():
            sysinfo.bt_scan(10)
            devs = sysinfo.bt_devices()
            GLib.idle_add(self._fill_bt, devs)

        threading.Thread(target=work, daemon=True).start()

    def _fill_bt(self, devs):
        self._bt_loading = False
        self._bt_items = devs
        self._bt_msg = "" if devs else _("Устройства не найдены — нажмите поиск")
        self._rebuild_nets()

    def _build_bt_body(self):
        body = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        if self._bt_msg:
            lbl = Gtk.Label(label=self._bt_msg, xalign=0)
            lbl.set_line_wrap(True)
            lbl.get_style_context().add_class("flyme-ok")
            body.pack_start(lbl, False, False, 0)
        if not self._bt_items:
            if not self._bt_msg:
                lbl = Gtk.Label(label=_("Поиск устройств…"), xalign=0)
                lbl.get_style_context().add_class("flyme-sub")
                body.pack_start(lbl, False, False, 0)
            return self._net_scroll(body, 1)
        for mac, name, connected, paired in self._bt_items:
            body.pack_start(self._bt_row(mac, name, connected, paired),
                            False, False, 0)
        return self._net_scroll(body, len(self._bt_items))

    def _bt_row(self, mac, name, connected, paired):
        pal = theme.palette()
        sub = theme.hex_rgba(pal["sub"])[:3]
        accent = theme.hex_rgba(pal["accent"])[:3]

        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        ctx = btn.get_style_context()
        ctx.add_class("flyme-netrow")
        if connected:
            ctx.add_class("flyme-netrow-active")
        hb = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hb.pack_start(widgets.IconArea("bluetooth",
                                       accent if connected else sub, 16),
                      False, False, 0)
        lbl = Gtk.Label(label=name or mac, xalign=0)
        lbl.set_ellipsize(Pango.EllipsizeMode.END)
        hb.pack_start(lbl, True, True, 0)
        if connected:
            st = Gtk.Label(label=_("подключено"))
            st.get_style_context().add_class("flyme-sub")
            hb.pack_end(st, False, False, 0)
        btn.add(hb)
        if connected:
            btn.connect("clicked", lambda *_: self._bt_do(mac, False))
        else:
            btn.connect("clicked", lambda *_: self._bt_do(mac, True))
        return btn

    def _bt_do(self, mac, connect):
        self._bt_msg = _("Подключение…") if connect else _("Отключение…")
        self._rebuild_nets()

        def work():
            if connect:
                good, msg = sysinfo.bt_connect(mac)
            else:
                sysinfo.bt_disconnect(mac)
                good, msg = True, ""
            devs = sysinfo.bt_devices()
            GLib.idle_add(self._after_bt, devs, good, msg)

        threading.Thread(target=work, daemon=True).start()

    def _after_bt(self, devs, good, msg):
        self._bt_items = devs
        self._bt_msg = "" if good else (_("Не удалось: %s") % (msg or _("ошибка")))
        self._rebuild_nets()

    # -------------------------------------------------------------- позиция

    def _position(self):
        geo = widgets.primary_geometry()
        req = self.get_preferred_width()
        width = max(WIDTH, req[1])
        height = self.get_preferred_height()[1]
        x = geo.x + geo.width - width - 12
        y = geo.y + 44
        self.resize(width, height)
        self.move(x, y)

    # ------------------------------------------------------------ обновление

    def _refresh(self):
        pal = theme.palette()

        wifi = sysinfo.wifi_enabled()
        self._set_tile("wifi", wifi, "wifi" if wifi else "wifi-off")
        bt = sysinfo.bt_powered()
        self._set_tile("bt", bt, "bluetooth")

        changed = False
        wifi_on = bool(wifi)
        if wifi_on != self._wifi_on:
            self._wifi_on = wifi_on
            changed = True
            if not wifi_on:
                self._wifi_nets = []
                self._wifi_saved = set()
                self._pw_ssid = None
        bt_on = bool(bt)
        if bt_on != self._bt_on:
            self._bt_on = bt_on
            changed = True
            if not bt_on:
                self._bt_items = []
        if changed:
            self._rebuild_nets()
        self._set_tile("dark", config.is_dark(), "contrast")
        self._set_tile("dnd", config.load().getboolean(
            "general", "dnd", fallback=False), "moon")

        # ползунки без ложных срабатываний
        self._suppress = True
        b = sysinfo.get_brightness()
        if b is not None:
            self.bright_scale.set_value(b)
        v = sysinfo.get_volume()
        if v is not None:
            self.vol_scale.set_value(v)
        self._suppress = False

        parts = []
        if wifi is not None:
            parts.append("Wi-Fi %s" % (_("вкл") if wifi else _("выкл")))
        if bt is not None:
            parts.append("Bluetooth %s" % (_("вкл") if bt else _("выкл")))
        if b is not None:
            parts.append(_("яркость %d%%") % b)
        if v is not None:
            parts.append(_("громкость %d%%") % v)
        self.state_label.set_text(" · ".join(parts) if parts else "")

    def _set_tile(self, key, active, icon):
        tile = self.tiles[key]
        pal = theme.palette()
        ctx = tile.get_style_context()
        if active:
            ctx.add_class("flyme-tile-active")
            color = (1, 1, 1)
        else:
            ctx.remove_class("flyme-tile-active")
            color = theme.hex_rgba(pal["text"])[:3]
        tile.tile_icon.set_icon(color=color, name=icon)

    # ------------------------------------------------------------- события

    def _on_tile(self, _w, _ev, key):
        if key == "wifi":
            cur = sysinfo.wifi_enabled()
            if cur is not None:
                sysinfo.set_wifi(not cur)
        elif key == "bt":
            cur = sysinfo.bt_powered()
            if cur is not None:
                sysinfo.set_bt(not cur)
        elif key == "dark":
            self._toggle_theme()
        elif key == "dnd":
            cfg = config.load()
            cur = cfg.getboolean("general", "dnd", fallback=False)
            config.set_option("general", "dnd", "true" if not cur else "false")
        GLib.timeout_add(400, self._refresh)
        return True

    def _toggle_theme(self):
        new = "dark" if not config.is_dark() else "light"
        config.set_option("general", "theme", new)
        # применяем к GTK-приложениям сеанса сразу
        gtk_theme = "flyme-gtk-dark" if new == "dark" else "flyme-gtk"
        wm_theme = "flyme-dark" if new == "dark" else "flyme-light"
        for channel, prop, value in (
            ("xsettings", "/Net/ThemeName", gtk_theme),
            ("xfwm4", "/general/theme", wm_theme),
        ):
            _spawn(["xfconf-query", "-c", channel, "-p", prop, "-s", value])
        GLib.timeout_add(400, self._refresh)

    def _on_bright(self, scale):
        if self._suppress:
            return
        sysinfo.set_brightness(scale.get_value())

    def _on_vol(self, scale):
        if self._suppress:
            return
        sysinfo.set_volume(scale.get_value())

    def _open_settings(self, *_a):
        for cmd in (["xfce4-settings-manager"], ["systemsettings"],
                    ["gnome-control-center"]):
            import shutil  # noqa: PLC0415
            if shutil.which(cmd[0]):
                _spawn(cmd)
                return
        _spawn(["xfce4-settings-manager"])

    def _power_menu(self, _btn):
        menu = Gtk.Menu()
        for label, action in (
            (_("Завершение работы"), sysinfo.poweroff),
            (_("Перезагрузка"), sysinfo.reboot),
            (_("Выход из сеанса"), sysinfo.logout),
        ):
            mi = Gtk.MenuItem(label=label)
            mi.connect("activate", lambda *_a, cb=action: cb())
            menu.append(mi)
        menu.show_all()
        menu.connect("selection-done", lambda m: GLib.idle_add(m.destroy))
        menu.popup_at_widget(self.tiles["wifi"], Gdk.Gravity.SOUTH_WEST,
                             Gdk.Gravity.NORTH_WEST, None)

    def _on_bg_press(self, _w, ev):
        if ev.button == 1:
            self.hide()
            return True
        return False

    def _on_key(self, _w, ev):
        if ev.keyval == Gdk.KEY_Escape:
            self.hide()
            return True
        return False

    def toggle(self):
        if self.get_visible():
            self.hide()
        else:
            self._pw_ssid = None
            self._pw_error = ""
            self._position()
            self._refresh()
            if self._wifi_on:
                self._reload_wifi()
            if self._bt_on:
                self._load_bt()
            self.show_all()
            self.present()


def main():
    ControlCenterApp().run([])


if __name__ == "__main__":
    main()
