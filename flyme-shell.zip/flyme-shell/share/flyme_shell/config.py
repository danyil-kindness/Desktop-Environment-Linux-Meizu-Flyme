# -*- coding: utf-8 -*-
"""Конфигурация оболочки: ~/.config/flyme-shell/config.ini."""

import configparser
import os

APP_NAME = "flyme-shell"
_XDG_CONFIG = os.environ.get(
    "XDG_CONFIG_HOME", os.path.join(os.path.expanduser("~"), ".config")
)
CONFIG_DIR = os.path.join(_XDG_CONFIG, APP_NAME)
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.ini")
_LOCK_DIR = os.environ.get("XDG_RUNTIME_DIR") or CONFIG_DIR
LOCK_FILE = os.path.join(_LOCK_DIR, "flyme-shell.lock")

DEFAULTS = {
    "general": {
        "theme": "light",       # light | dark
        "accent": "#0088FF",
        "language": "auto",     # auto | ru | en | pl | uk
    },
    "panel": {
        "height": "36",
        "show_date": "true",
    },
    "dock": {
        "icon_size": "44",
        "autohide": "false",
        "pinned": "",           # пусто = подобрать автоматически при первом запуске
    },
    "lock": {
        # ВНИМАНИЕ: flyme-lock — только «красивая» блокировка.
        # Для настоящей защиты поставьте сюда: light-locker-command -l
        "command": "flyme-lock",
    },
}


def load():
    """Вернуть configparser с применёнными DEFAULTS (без записи на диск)."""
    cfg = configparser.ConfigParser()
    for sect, opts in DEFAULTS.items():
        cfg[sect] = dict(opts)
    if os.path.isfile(CONFIG_FILE):
        try:
            cfg.read(CONFIG_FILE, encoding="utf-8")
        except Exception:
            pass
    # гарантируем наличие всех секций/ключей
    for sect, opts in DEFAULTS.items():
        if not cfg.has_section(sect):
            cfg[sect] = dict(opts)
        for key, val in opts.items():
            if not cfg.has_option(sect, key):
                cfg.set(sect, key, val)
    return cfg


def save(cfg):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
        cfg.write(fh)


def get(section, option, fallback=""):
    cfg = load()
    return cfg.get(section, option, fallback=fallback)


def set_option(section, option, value):
    cfg = load()
    cfg.set(section, option, str(value))
    save(cfg)


def is_dark():
    return get("general", "theme").strip().lower() == "dark"


# ------------------------------------------------------- состояние блокировки

def set_locked(pid=None):
    """Пометить сеанс как заблокированный (файл с PID процесса блокировки)."""
    try:
        os.makedirs(os.path.dirname(LOCK_FILE), exist_ok=True)
        with open(LOCK_FILE, "w", encoding="ascii") as fh:
            fh.write(str(pid if pid is not None else os.getpid()))
    except OSError:
        pass


def clear_locked():
    try:
        os.unlink(LOCK_FILE)
    except OSError:
        pass


def is_locked():
    """True, если активен живой процесс блокировки (устаревший файл чистим)."""
    try:
        with open(LOCK_FILE, encoding="ascii") as fh:
            pid = int(fh.read().strip() or "0")
    except (OSError, ValueError):
        return False
    if pid <= 0:
        return False
    if pid == os.getpid():
        return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        clear_locked()
        return False
    except PermissionError:
        return True


def watch(callback):
    """Вызывать callback() при изменении файла конфигурации."""
    from gi.repository import Gio, GLib  # noqa: PLC0415
    os.makedirs(CONFIG_DIR, exist_ok=True)
    if not os.path.exists(CONFIG_FILE):
        save(load())
    gfile = Gio.File.new_for_path(CONFIG_FILE)
    monitor = gfile.monitor_file(Gio.FileMonitorFlags.NONE, None)
    monitor.connect("changed", lambda *a: GLib.idle_add(callback))
    return monitor  # держать ссылку!


def default_pinned():
    """Подобрать закреплённые приложения по умолчанию (первые подходящие)."""
    from . import apps  # noqa: PLC0415
    wanted = [
        "firefox", "firefox-esr", "chromium", "google-chrome", "brave-browser",
        "thunar", "org.gnome.Nautilus", "nemo", "caja",
        "xfce4-terminal", "org.gnome.Terminal", "gnome-terminal", "konsole",
        "kitty", "alacritty", "xterm", "code", "vscode", "gedit", "xed",
        "mousepad", "gimp", "libreoffice", "org.telegram.desktop", "discord",
        "spotify", "thunderbird",
    ]
    have = {a.app_id: a for a in apps.list_apps()}
    picked = [w for w in wanted if w in have]
    for aid in sorted(have):  # добить до 5 любыми
        if len(picked) >= 5:
            break
        if aid not in picked:
            picked.append(aid)
    return ",".join(picked[:5])
