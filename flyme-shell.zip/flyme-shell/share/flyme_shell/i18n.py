# -*- coding: utf-8 -*-
"""Локализация оболочки: русский, английский, польский, украинский.

Язык берётся из ``[general] language`` в config.ini:

* ``auto`` — язык системы, если он один из поддерживаемых, иначе английский;
* ``ru`` / ``en`` / ``pl`` / ``uk`` — принудительно.

Строки в коде написаны по-русски и служат ключами каталога.
"""

import os

from . import config

LANGUAGES = ("ru", "en", "pl", "uk")

NAMES = {
    "ru": "Русский",
    "en": "English",
    "pl": "Polski",
    "uk": "Українська",
}

# ru, en, pl, uk
_TABLE = [
    # --- панель -----------------------------------------------------------
    ("Приложения (Super+Пробел)",
     "Apps (Super+Space)", "Aplikacje (Super+Spacja)", "Програми (Super+Пробіл)"),
    ("Громкость: колесо — регулировка",
     "Volume: use the wheel", "Głośność: regulacja kółkiem",
     "Гучність: регулювання колесом"),
    ("Уведомления: «Не беспокоить»",
     "Notifications: Do not disturb", "Powiadomienia: Nie przeszkadzać",
     "Сповіщення: Не турбувати"),
    ("Центр управления (Super+A)",
     "Control Center (Super+A)", "Centrum sterowania (Super+A)",
     "Центр керування (Super+A)"),
    ("Календарь", "Calendar", "Kalendarz", "Календар"),
    ("Громкость: %s · колесо — регулировка, Shift+колесо — яркость",
     "Volume: %s · wheel — volume, Shift+wheel — brightness",
     "Głośność: %s · kółko — głośność, Shift+kółko — jasność",
     "Гучність: %s · колесо — гучність, Shift+колесо — яскравість"),
    ("«Не беспокоить»: вкл",
     "Do not disturb: on", "Nie przeszkadzać: wł.", "Не турбувати: увімк."),
    ("«Не беспокоить»: выкл",
     "Do not disturb: off", "Nie przeszkadzać: wył.", "Не турбувати: вимк."),
    ("Лаунчер приложений",
     "App launcher", "Launcher aplikacji", "Лаунчер програм"),
    ("Перезапустить панель",
     "Restart panel", "Uruchom panel ponownie", "Перезапустити панель"),
    ("Выйти из сеанса Flyme",
     "Log out of Flyme", "Wyloguj z Flyme", "Вийти із сеансу Flyme"),

    # --- центр управления -------------------------------------------------
    ("Центр управления",
     "Control Center", "Centrum sterowania", "Центр керування"),
    ("<b>Центр управления</b>",
     "<b>Control Center</b>", "<b>Centrum sterowania</b>",
     "<b>Центр керування</b>"),
    ("Тёмная тема", "Dark theme", "Ciemny motyw", "Темна тема"),
    ("Не беспокоить", "Do not disturb", "Nie przeszkadzać", "Не турбувати"),
    ("Яркость", "Brightness", "Jasność", "Яскравість"),
    ("Громкость", "Volume", "Głośność", "Гучність"),
    ("Настройки", "Settings", "Ustawienia", "Налаштування"),
    ("Заблокировать", "Lock", "Zablokuj", "Заблокувати"),
    ("Питание", "Power", "Zasilanie", "Живлення"),
    ("Язык", "Language", "Język", "Мова"),
    ("Как в системе", "Same as system", "Jak w systemie", "Як у системі"),
    ("Обновить список", "Refresh list", "Odśwież listę", "Оновити список"),
    ("Сети Wi-Fi", "Wi-Fi networks", "Sieci Wi-Fi", "Мережі Wi-Fi"),
    ("Wi-Fi выключен — нажмите плитку выше",
     "Wi-Fi is off — tap the tile above",
     "Wi-Fi wyłączone — naciśnij kafelek powyżej",
     "Wi-Fi вимкнено — натисніть плитку вище"),
    ("Устройства Bluetooth",
     "Bluetooth devices", "Urządzenia Bluetooth", "Пристрої Bluetooth"),
    ("Поиск сетей…", "Scanning for networks…",
     "Wyszukiwanie sieci…", "Пошук мереж…"),
    ("Сети не найдены", "No networks found",
     "Nie znaleziono sieci", "Мереж не знайдено"),
    ("подключено", "connected", "połączono", "підключено"),
    ("Отключиться от сети", "Disconnect from network",
     "Rozłącz z siecią", "Від’єднатися від мережі"),
    ("Ввести пароль", "Enter password", "Wpisz hasło", "Ввести пароль"),
    ("Пароль сети «%s»", "Password for “%s”",
     "Hasło sieci „%s”", "Пароль мережі «%s»"),
    ("Подключиться", "Connect", "Połącz", "Підключитися"),
    ("Показать пароль", "Show password", "Pokaż hasło", "Показати пароль"),
    ("Подключение…", "Connecting…", "Łączenie…", "Підключення…"),
    ("Подключение к «%s»…", "Connecting to “%s”…",
     "Łączenie z „%s”…", "Підключення до «%s»…"),
    ("Не удалось: %s", "Failed: %s", "Nie udało się: %s", "Не вдалося: %s"),
    ("Неверный пароль", "Wrong password",
     "Nieprawidłowe hasło", "Невірний пароль"),
    ("Сеть не найдена", "Network not found",
     "Nie znaleziono sieci", "Мережу не знайдено"),
    ("Истекло время ожидания", "Timed out",
     "Przekroczono czas oczekiwania", "Час очікування вичерпано"),
    ("Не удалось подключиться", "Could not connect",
     "Nie udało się połączyć", "Не вдалося підключитися"),
    ("Отключение…", "Disconnecting…", "Rozłączanie…", "Від’єднання…"),
    ("Поиск устройств…", "Searching for devices…",
     "Wyszukiwanie urządzeń…", "Пошук пристроїв…"),
    ("Поиск устройств… (10 секунд)", "Searching for devices… (10 seconds)",
     "Wyszukiwanie urządzeń… (10 sekund)", "Пошук пристроїв… (10 секунд)"),
    ("Устройства не найдены — нажмите поиск",
     "No devices found — tap search",
     "Nie znaleziono urządzeń — naciśnij wyszukiwanie",
     "Пристроїв не знайдено — натисніть пошук"),
    ("ошибка", "error", "błąd", "помилка"),
    ("вкл", "on", "wł.", "увімк."),
    ("выкл", "off", "wył.", "вимк."),
    ("яркость %d%%", "brightness %d%%", "jasność %d%%", "яскравість %d%%"),
    ("громкость %d%%", "volume %d%%", "głośność %d%%", "гучність %d%%"),
    ("Завершение работы", "Shut down", "Wyłącz komputer", "Завершити роботу"),
    ("Перезагрузка", "Restart", "Uruchom ponownie", "Перезавантаження"),
    ("Выход из сеанса", "Log out", "Wyloguj", "Вийти із сеансу"),

    # --- док --------------------------------------------------------------
    ("Активировать окно", "Activate window",
     "Aktywuj okno", "Активувати вікно"),
    ("Открепить", "Unpin", "Odepnij", "Відкріпити"),
    ("Закрепить", "Pin", "Przypnij", "Закріпити"),
    ("Закрыть окна", "Close windows", "Zamknij okna", "Закрити вікна"),

    # --- лаунчер ----------------------------------------------------------
    ("Поиск приложений…", "Search apps…",
     "Szukaj aplikacji…", "Пошук програм…"),
    ("Колесо мыши — прокрутка · Enter — запустить · Esc — закрыть",
     "Wheel — scroll · Enter — launch · Esc — close",
     "Kółko myszy — przewijanie · Enter — uruchom · Esc — zamknij",
     "Колесо миші — прокручування · Enter — запустити · Esc — закрити"),

    # --- блокировка -------------------------------------------------------
    ("Разблокировать", "Unlock", "Odblokuj", "Розблокувати"),
    ("Нажмите Enter или Esc, чтобы разблокировать",
     "Press Enter or Esc to unlock",
     "Naciśnij Enter lub Esc, aby odblokować",
     "Натисніть Enter або Esc, щоб розблокувати"),

    # --- системные сообщения ---------------------------------------------
    ("nmcli не найден", "nmcli not found",
     "nie znaleziono nmcli", "nmcli не знайдено"),
    ("истекло время ожидания", "timed out",
     "przekroczono czas oczekiwania", "час очікування вичерпано"),
    ("bluetoothctl не найден", "bluetoothctl not found",
     "nie znaleziono bluetoothctl", "bluetoothctl не знайдено"),
    ("не удалось подключиться", "could not connect",
     "nie udało się połączyć", "не вдалося підключитися"),

    # --- список окон ------------------------------------------------------
    ("Окно", "Window", "Okno", "Вікно"),
    ("Развернуть", "Restore", "Przywróć", "Розгорнути"),
    ("Свернуть", "Minimize", "Minimalizuj", "Згорнути"),
    ("Восстановить размер", "Unmaximize",
     "Przywróć rozmiar", "Відновити розмір"),
    ("Развернуть на весь экран", "Maximize",
     "Maksymalizuj", "Розгорнути на весь екран"),
    ("Закрыть", "Close", "Zamknij", "Закрити"),
]

CATALOG = {code: {} for code in LANGUAGES}
for _row in _TABLE:
    _ru, _en, _pl, _uk = _row
    CATALOG["ru"][_ru] = _ru
    CATALOG["en"][_ru] = _en
    CATALOG["pl"][_ru] = _pl
    CATALOG["uk"][_ru] = _uk
del _row, _ru, _en, _pl, _uk


# ------------------------------------------------------------------ месяцы

MONTHS_NOM = {
    "ru": ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
           "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"],
    "en": ["January", "February", "March", "April", "May", "June",
           "July", "August", "September", "October", "November", "December"],
    "pl": ["Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec",
           "Lipiec", "Sierpień", "Wrzesień", "Październik", "Listopad",
           "Grudzień"],
    "uk": ["Січень", "Лютий", "Березень", "Квітень", "Травень", "Червень",
           "Липень", "Серпень", "Вересень", "Жовтень", "Листопад",
           "Грудень"],
}

MONTHS_GEN = {
    "ru": ["января", "февраля", "марта", "апреля", "мая", "июня",
           "июля", "августа", "сентября", "октября", "ноября", "декабря"],
    "en": ["January", "February", "March", "April", "May", "June",
           "July", "August", "September", "October", "November", "December"],
    "pl": ["stycznia", "lutego", "marca", "kwietnia", "maja", "czerwca",
           "lipca", "sierpnia", "września", "października", "listopada",
           "grudnia"],
    "uk": ["січня", "лютого", "березня", "квітня", "травня", "червня",
           "липня", "серпня", "вересня", "жовтня", "листопада", "грудня"],
}

DAYS_SHORT = {
    "ru": ["пн", "вт", "ср", "чт", "пт", "сб", "вс"],
    "en": ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    "pl": ["Pn", "Wt", "Śr", "Cz", "Pt", "So", "Nd"],
    "uk": ["пн", "вт", "ср", "чт", "пт", "сб", "нд"],
}

DAYS_FULL = {
    "ru": ["понедельник", "вторник", "среда", "четверг", "пятница",
           "суббота", "воскресенье"],
    "en": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday",
           "Saturday", "Sunday"],
    "pl": ["poniedziałek", "wtorek", "środa", "czwartek", "piątek",
           "sobota", "niedziela"],
    "uk": ["понеділок", "вівторок", "середа", "четвер", "п’ятниця",
           "субота", "неділя"],
}


# -------------------------------------------------------------- определение

_cached = None
_cached_key = None
_started = None


def _code_from(value):
    """«pl_PL.UTF-8» -> «pl»."""
    first = (value or "").split(":")[0].strip()
    if not first:
        return ""
    return first.split(".")[0].split("@")[0].split("_")[0].lower()


def system_language():
    """Язык системы, если он поддерживается, иначе английский."""
    for var in ("LC_ALL", "LC_MESSAGES", "LANG"):
        raw = (os.environ.get(var) or "").strip()
        if not raw:
            continue
        code = _code_from(raw)
        if code in LANGUAGES:
            return code
        if code and code not in ("c", "posix"):
            return "en"
    # переменные не заданы или C/POSIX — смотрим подсказку gettext
    for item in (os.environ.get("LANGUAGE") or "").split(":"):
        code = _code_from(item)
        if code in LANGUAGES:
            return code
    return "en"


def configured():
    """Значение language из конфига («auto» или код языка)."""
    try:
        value = (config.get("general", "language", "auto") or "auto").strip()
    except Exception:
        return "auto"
    return value.lower()


def current():
    """Действующий язык интерфейса."""
    global _cached, _cached_key
    try:
        stat = os.stat(config.CONFIG_FILE)
        key = (stat.st_mtime_ns, stat.st_size)
    except OSError:
        key = (0, 0)
    if _cached is None or key != _cached_key:
        code = configured()
        if code not in LANGUAGES:
            code = system_language()
        _cached = code
        _cached_key = key
    return _cached


def started():
    """Язык, с которым запущен процесс (для отслеживания смены)."""
    global _started
    if _started is None:
        _started = current()
    return _started


def mark_started():
    """Запомнить текущий язык как «язык запуска» (после пересборки окна)."""
    global _started
    _started = current()


def reload():
    """Сбросить кэш (после изменения настроек в этом же процессе)."""
    global _cached, _cached_key
    _cached = None
    _cached_key = None


# ------------------------------------------------------------- перевод строк

def gettext(text):
    """Перевести строку (ключ — русский текст)."""
    code = current()
    if code == "ru":
        return text
    table = CATALOG.get(code) or {}
    if text in table:
        return table[text]
    return CATALOG["en"].get(text, text)


def months_nom():
    return MONTHS_NOM[current()]


def months_gen():
    return MONTHS_GEN[current()]


def days_short():
    return DAYS_SHORT[current()]


def date_text(dt):
    """«29 октября 2026» / «October 29, 2026» / «29 października 2026»."""
    month = months_gen()[dt.month - 1]
    if current() == "en":
        return "%s %d, %d" % (month, dt.day, dt.year)
    return "%d %s %d" % (dt.day, month, dt.year)


def weekday_text(dt):
    return DAYS_FULL[current()][dt.weekday()]


# короткое имя для разметки строк: _( "..." )
_ = gettext
