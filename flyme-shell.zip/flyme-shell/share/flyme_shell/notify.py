# -*- coding: utf-8 -*-
"""Сервер уведомлений org.freedesktop.Notifications + тосты в стиле Flyme."""

import os
import re
import time

import dbus
import dbus.service
from dbus.mainloop.glib import DBusGMainLoop

from gi.repository import Gdk, GLib, Gtk, Pango

from . import apps as appinfo
from . import config, theme, widgets

IFACE = "org.freedesktop.Notifications"
MAX_VISIBLE = 3
TOAST_WIDTH = 340
PANEL_GAP = 44


def _strip_markup(text):
    return re.sub(r"<[^>]+>", "", str(text or ""))


class ToastWindow(Gtk.Window):
    def __init__(self, summary, body, icon_name, on_close):
        super().__init__()
        self.set_type_hint(Gdk.WindowTypeHint.NOTIFICATION)
        self.set_decorated(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_default_size(TOAST_WIDTH, -1)
        widgets.set_rgba(self)
        self.on_close = on_close
        self._closed = False

        card = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        card.set_margin_top(12)
        card.set_margin_bottom(12)
        card.set_margin_start(14)
        card.set_margin_end(14)
        card.get_style_context().add_class("flyme-toast-card")
        card.connect("button-press-event", self._on_click)

        icon = Gtk.Image()
        try:
            names = [icon_name] if icon_name else []
            names += ["preferences-system", "dialog-information"]
            pb = None
            for name in names:
                pb = appinfo.load_icon(name, 32)
                if pb is not None:
                    break
            icon.set_from_pixbuf(pb)
        except Exception:
            icon.set_from_icon_name("preferences-system", Gtk.IconSize.DIALOG)
        card.pack_start(icon, False, False, 0)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title = Gtk.Label()
        title.set_markup("<b>%s</b>" % GLib.markup_escape_text(_strip_markup(summary)))
        title.set_halign(Gtk.Align.START)
        title.set_ellipsize(Pango.EllipsizeMode.END)
        title.set_max_width_chars(32)
        vbox.pack_start(title, False, False, 0)
        if body:
            lbl = Gtk.Label(label=_strip_markup(body))
            lbl.set_halign(Gtk.Align.START)
            lbl.set_ellipsize(Pango.EllipsizeMode.END)
            lbl.set_line_wrap(True)
            lbl.set_max_width_chars(36)
            lbl.get_style_context().add_class("flyme-toast-body")
            vbox.pack_start(lbl, False, False, 0)
        card.pack_start(vbox, True, True, 0)

        self.add(card)
        self.get_style_context().add_class("flyme-toast")
        pal = theme.palette()
        widgets.apply_css_screen("""
            window.flyme-toast {{ background-color: transparent; }}
            .flyme-toast-card {{
                background-color: {surface};
                border: 1px solid {border};
                border-radius: 14px;
                color: {text};
            }}
            .flyme-toast-body {{ color: {sub}; font-size: 12px; }}
        """.format(**pal))
        self.connect("button-press-event", self._on_click)

    def _on_click(self, _w, ev):
        if ev.button == 1 or ev.button == 2:
            self.close_toast(reason=2)
            return True
        return False

    def close_toast(self, reason=1):
        if self._closed:
            return
        self._closed = True
        self.destroy()
        if self.on_close:
            self.on_close(self, reason)


class FlymeNotifications(dbus.service.Object):
    def __init__(self, bus, app):
        self.next_id = 1
        self.toasts = []          # [(ToastWindow, id, timeout_id)]
        self.app = app
        super().__init__(bus, "/org/freedesktop/Notifications")

    # -------------------------------------------------------------DBus API

    @dbus.service.method(IFACE, in_signature="susssasa{sv}i",
                         out_signature="u")
    def Notify(self, app_name, replaces_id, app_icon, summary, body,
               actions, hints, expire_timeout):
        nid = int(replaces_id) or self.next_id
        if not int(replaces_id):
            self.next_id += 1
            nid = self.next_id - 1

        dnd = config.load().getboolean("general", "dnd", fallback=False)
        if dnd:
            return dbus.UInt32(nid)

        icon_name = str(app_icon or "")
        if not icon_name and hints:
            for key in ("app-icon", "icon-name"):
                if key in hints:
                    icon_name = str(hints[key])
                    break
        if not icon_name:
            icon_name = "preferences-system"

        timeout = int(expire_timeout)
        if timeout == 0:
            timeout_ms = 0            # не закрывать автоматически
        elif timeout < 0:
            timeout_ms = 6000
        else:
            timeout_ms = max(2000, min(15000, timeout))

        GLib.idle_add(self._show_toast, str(summary), str(body),
                      icon_name, nid, timeout_ms)
        return dbus.UInt32(nid)

    @dbus.service.method(IFACE, in_signature="u", out_signature="")
    def CloseNotification(self, nid):
        GLib.idle_add(self._close_by_id, int(nid), 3)

    @dbus.service.method(IFACE, in_signature="", out_signature="as")
    def GetCapabilities(self):
        return ["body", "persistence"]

    @dbus.service.method(IFACE, in_signature="", out_signature="ssss")
    def GetServerInformation(self):
        return ("Flyme Shell", "flyme-shell", "1.0.0", "1.2")

    @dbus.service.signal(IFACE, signature="us")
    def NotificationClosed(self, nid, reason):
        pass

    @dbus.service.signal(IFACE, signature="us")
    def ActionInvoked(self, nid, action_key):
        pass

    # ------------------------------------------------------------- тосты

    def _show_toast(self, summary, body, icon_name, nid, timeout_ms):
        if config.is_locked():
            return False
        toast = ToastWindow(summary, body, icon_name,
                            lambda t, reason: self._on_closed(t, reason, nid))
        self.toasts.append((toast, nid, 0))
        self._reposition()
        toast.show_all()
        if timeout_ms > 0:
            tid = GLib.timeout_add(timeout_ms, self._timeout, toast, nid)
            for i, (t, n, _old) in enumerate(self.toasts):
                if t is toast:
                    self.toasts[i] = (t, n, tid)
        # держим не больше MAX_VISIBLE
        while len(self.toasts) > MAX_VISIBLE:
            t, n, tid = self.toasts.pop(0)
            if tid:
                GLib.source_remove(tid)
            self.NotificationClosed(dbus.UInt32(n), dbus.UInt32(2))
            t.destroy()
        self._reposition()
        return False

    def _timeout(self, toast, nid):
        for i, (t, n, tid) in enumerate(self.toasts):
            if t is toast and n == nid:
                self.toasts.pop(i)
                break
        self.NotificationClosed(dbus.UInt32(nid), dbus.UInt32(1))
        toast.destroy()
        self._reposition()
        return False

    def _close_by_id(self, nid, reason):
        for i, (t, n, tid) in enumerate(self.toasts):
            if n == nid:
                if tid:
                    GLib.source_remove(tid)
                self.toasts.pop(i)
                t.destroy()
                self.NotificationClosed(dbus.UInt32(nid), dbus.UInt32(reason))
                break
        self._reposition()
        return False

    def _on_closed(self, toast, reason, nid):
        for i, (t, n, tid) in enumerate(self.toasts):
            if t is toast:
                if tid:
                    GLib.source_remove(tid)
                self.toasts.pop(i)
                break
        self.NotificationClosed(dbus.UInt32(nid), dbus.UInt32(reason))
        self._reposition()

    def _lock_tick(self):
        if config.is_locked():
            for toast, _nid, _tid in list(self.toasts):
                toast.hide()
        return True

    def _reposition(self):
        geo = widgets.primary_geometry()
        y = geo.y + PANEL_GAP
        width = TOAST_WIDTH
        x = geo.x + geo.width - width - 14
        for toast, _nid, _tid in reversed(self.toasts):
            toast.move(x, y)
            h = toast.get_allocated_height() or 70
            y += h + 10


def main():
    DBusGMainLoop(set_as_default=True)
    bus = dbus.SessionBus()
    try:
        name = dbus.service.BusName(IFACE, bus, do_not_queue=True)
    except dbus.exceptions.NameExistsException:
        print("flyme-notifications: имя %s уже занято — уведомления ведёт "
              "другая программа." % IFACE)
        os._exit(1)

    # Важно: Gtk.Application.run() конфликтует с диспетчеризацией вызовов
    # dbus-python (методы перестают отвечать), поэтому используем Gtk.main().
    server = FlymeNotifications(bus, None)
    _ = server  # держим ссылку на экспортированный объект
    GLib.timeout_add(700, server._lock_tick)
    Gtk.main()


if __name__ == "__main__":
    main()
