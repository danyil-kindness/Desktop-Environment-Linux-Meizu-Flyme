# -*- coding: utf-8 -*-
"""Общие GTK-виджеты и помощники для окон оболочки."""

import os
import sys

from gi.repository import Gdk, Gio, GLib, Gtk

from . import config, i18n, theme, x11


class ShellApp(Gio.Application):
    """Один экземпляр компонента оболочки (аналог Gtk.Application).

    Gtk.Application при старте синхронно спрашивает xdg-desktop-portal; если
    портал в системе отвечает медленно, окно появляется только через ~25 с.
    Gio.Application даёт то же единичное владение D-Bus-именем и активацию
    второго запуска, но портал не задействует.
    """

    def __init__(self, app_id):
        super().__init__(application_id=app_id)

    def track(self, window):
        """Держать приложение живым, пока окно не закрыто."""
        self.hold()
        window.connect("destroy", lambda *_a: self.release())
        return window


class IconArea(Gtk.DrawingArea):
    """Компактная иконка, нарисованная cairo."""

    def __init__(self, name, color=(0, 0, 0), size=24, **kw):
        super().__init__()
        self.icon_name = name
        self.icon_color = color
        self.icon_size = size
        self.icon_kwargs = kw
        self.set_size_request(size, size)
        self.connect("draw", self._on_draw)

    def set_icon(self, name=None, color=None, **kw):
        if name:
            self.icon_name = name
        if color is not None:
            self.icon_color = color
        self.icon_kwargs = kw
        self.queue_draw()

    def _on_draw(self, _area, cr):
        theme.draw(
            cr, self.icon_name, self.icon_color, self.icon_size, **self.icon_kwargs
        )
        return False


def css_provider(data):
    provider = Gtk.CssProvider()
    provider.load_from_data(data.encode("utf-8"))
    return provider


def apply_css(widget, data, priority=Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION):
    """CSS только для самого виджета (не для его потомков)."""
    widget.get_style_context().add_provider(css_provider(data), priority)


def add_screen_provider(provider, priority=Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 10):
    """Добавить провайдер для всего экрана: правила действуют и на потомков."""
    screen = Gdk.Screen.get_default()
    if screen is not None:
        Gtk.StyleContext.add_provider_for_screen(screen, provider, priority)
    return provider


def remove_screen_provider(provider):
    screen = Gdk.Screen.get_default()
    if screen is not None:
        Gtk.StyleContext.remove_provider_for_screen(screen, provider)


def apply_css_screen(data, priority=Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 10):
    return add_screen_provider(css_provider(data), priority)


def update_provider(provider, data):
    try:
        provider.load_from_data(data.encode("utf-8"))
    except Exception:
        pass


def set_rgba(window):
    screen = window.get_screen()
    visual = screen.get_rgba_visual()
    if visual and screen.is_composited():
        window.set_visual(visual)
        return True
    return False


def primary_geometry():
    display = Gdk.Display.get_default()
    monitor = display.get_primary_monitor()
    if monitor is None and display.get_n_monitors() > 0:
        monitor = display.get_monitor(0)
    if monitor is None:
        return Gdk.Rectangle()
    return monitor.get_geometry()


def workarea_geometry():
    """Рабочая область основного монитора (без полосы, занятой панелью)."""
    display = Gdk.Display.get_default()
    monitor = display.get_primary_monitor()
    if monitor is None and display.get_n_monitors() > 0:
        monitor = display.get_monitor(0)
    if monitor is None:
        return primary_geometry()
    try:
        wa = monitor.get_workarea()
        if wa and wa.width > 0 and wa.height > 0:
            return wa
    except Exception:
        pass
    return primary_geometry()


def fullscreen_on_geometry(window, geo=None):
    """Развернуть окно на заданном мониторе (совместимо со старым GI)."""
    if geo is None:
        geo = primary_geometry()
    screen = window.get_screen()
    cx = geo.x + max(1, geo.width // 2)
    cy = geo.y + max(1, geo.height // 2)
    try:
        idx = screen.get_monitor_at_point(cx, cy)
    except Exception:
        idx = 0
    try:
        window.fullscreen_on_monitor(screen, idx)
    except TypeError:
        try:
            window.fullscreen()
        except Exception:
            pass


def reserve_top(window, size):
    window.get_window().stick()
    GLib_idle_strut(window, "top", size)


def GLib_idle_strut(gdk_window, side, size):
    """gdk_window — GdkWindow окна (window.get_window())."""
    from gi.repository import GLib  # noqa: PLC0415

    def do():
        geo = primary_geometry()
        x11.set_strut(gdk_window, side, size, geo.width, geo.height)
        return False

    GLib.idle_add(do)


class ThemedWindow(Gtk.Window):
    """Окно с переключаемой темой: переопределяйте build_css() и apply_theme()."""

    #: перезапускать процесс при смене языка (окно настроек — False)
    relaunch_on_language = True

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._theme_providers = []
        self._screen_providers = []
        self._config_monitor = config.watch(self._on_config_changed)
        self.connect("destroy", self._drop_screen_providers)
        # монитор конфига держит ссылку на окно: отпускаем её при закрытии,
        # иначе PyGObject финализирует окно позже и может уронить процесс
        self.connect("destroy", lambda *_: GLib.idle_add(self._drop_monitor))
        GLib.timeout_add(500, self._lock_watch)

    def _drop_monitor(self):
        monitor = getattr(self, "_config_monitor", None)
        self._config_monitor = None
        if monitor is not None:
            try:
                monitor.cancel()
            except Exception:
                pass
        return False

    def _lock_watch(self):
        """Скрыть оверлеи при блокировке (панель/док показываются сами)."""
        if config.is_locked() and self.get_visible():
            self.hide()
        return True

    def use_css(self, provider):
        """Подключить CSS-провайдер ко всему экрану (для дочерних виджетов)."""
        add_screen_provider(provider)
        if provider not in self._screen_providers:
            self._screen_providers.append(provider)

    def _drop_screen_providers(self, *_a):
        for provider in self._screen_providers:
            remove_screen_provider(provider)
        self._screen_providers = []

    def build_css(self):
        return ""

    def apply_theme(self):
        raise NotImplementedError

    def refresh_css(self):
        self.apply_theme()

    def _on_config_changed(self):
        if self.relaunch_on_language and i18n.started() != i18n.current():
            # язык сменился: переводить все подписи на лету слишком сложно,
            # поэтому компонент перезапускается с новым языком
            GLib.idle_add(self._relaunch)
            return False
        if self.get_window() is not None:
            self.refresh_css()
        return False

    def _relaunch(self):
        argv = list(getattr(sys, "argv", None) or [])
        exe = sys.executable or ""
        if not argv or not exe or not os.path.isfile(argv[0] or ""):
            return False
        try:
            os.execv(exe, [exe, os.path.abspath(argv[0])] + argv[1:])
        except Exception:
            pass
        return False


def icon_button(icon_name, color, size=24, icon_size=20, tooltip=""):
    """Кнопка-иконка без рамки."""
    btn = Gtk.Button()
    btn.set_relief(Gtk.ReliefStyle.NONE)
    btn.set_can_focus(False)
    area = IconArea(icon_name, color, icon_size)
    btn.add(area)
    btn.icon_area = area
    if tooltip:
        btn.set_tooltip_text(tooltip)
    css = "button { background: transparent; border: none; border-radius: 8px; padding: 4px; }" \
          "button:hover { background-color: rgba(127,127,127,0.18); }"
    apply_css(btn, css)
    return btn


def ru_date(dt):
    return i18n.date_text(dt)


def ru_weekday(dt):
    return i18n.weekday_text(dt)
