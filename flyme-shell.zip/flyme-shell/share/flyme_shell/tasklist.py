# -*- coding: utf-8 -*-
"""Список открытых окон для верхней панели (как панель задач)."""

from gi.repository import GLib, Gtk, Pango

from . import windows
from .i18n import _

MAX_CHARS = 26


class TaskList(Gtk.Box):
    """Кнопки открытых окон: клик — свернуть/развернуть, ПКМ — меню."""

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        self.set_valign(Gtk.Align.CENTER)
        self._buttons = {}          # xid -> [button, подпись-состояние]
        self._scr = windows.screen()
        if self._scr is not None:
            for sig in ("window-opened", "window-closed",
                        "active-window-changed"):
                try:
                    self._scr.connect(sig, self._on_screen_signal)
                except Exception:
                    pass
        GLib.timeout_add_seconds(2, self.refresh)
        self.refresh()

    # --------------------------------------------------------------- события

    def _on_screen_signal(self, *_args):
        GLib.idle_add(self.refresh)
        return False

    def refresh(self):
        """Синхронизировать кнопки с открытыми окнами (без пересоздания)."""
        items = windows.windows()
        alive = set()
        for index, win in enumerate(items):
            xid = win.get_xid()
            alive.add(xid)
            state = self._state(win)
            entry = self._buttons.get(xid)
            if entry is None:
                entry = [self._make_button(win), state]
                self._buttons[xid] = entry
                self.pack_start(entry[0], False, False, 0)
            elif entry[1] != state:
                self._update_button(entry[0], win, state)
                entry[1] = state
            self.reorder_child(entry[0], index)

        for xid in [x for x in self._buttons if x not in alive]:
            btn = self._buttons.pop(xid)[0]
            self.remove(btn)
            # гасим кнопку сразу: иначе PyGObject финализирует её позже,
            # внутри обработки чужого сигнала, и процесс падает
            btn.destroy()

        self.show_all()
        return False

    @staticmethod
    def _state(win):
        return (win.get_name(),
                bool(win.is_active()) and not bool(win.is_minimized()))

    # -------------------------------------------------------------- кнопки

    def _make_button(self, win):
        state = self._state(win)
        btn = Gtk.Button()
        btn.set_relief(Gtk.ReliefStyle.NONE)
        btn.set_can_focus(False)
        btn.get_style_context().add_class("flyme-task")
        if state[1]:
            btn.get_style_context().add_class("flyme-task-active")

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        pb = windows.icon_pixbuf(win, 16)
        icon = Gtk.Image()
        if pb is not None:
            icon.set_from_pixbuf(pb)
        else:
            icon.set_from_icon_name("application-x-executable",
                                    Gtk.IconSize.MENU)
        box.pack_start(icon, False, False, 0)

        label = Gtk.Label(label=state[0] or _("Окно"))
        label.set_ellipsize(Pango.EllipsizeMode.END)
        label.set_max_width_chars(MAX_CHARS)
        label.set_xalign(0.0)
        box.pack_start(label, False, False, 0)

        btn.add(box)
        btn.task_label = label
        btn.set_tooltip_text(state[0] or _("Окно"))
        # в замыканиях держим только XID: ссылка на Wnck.Window в обработчике
        # приводит к падению PyGObject при закрытии окна
        xid = win.get_xid()
        btn.connect("clicked", self._on_clicked, xid)
        btn.connect("button-press-event", self._on_press, xid)
        return btn

    @staticmethod
    def _update_button(btn, win, state):
        name, active = state
        if btn.task_label.get_text() != (name or _("Окно")):
            btn.task_label.set_text(name or _("Окно"))
            btn.set_tooltip_text(name or _("Окно"))
        ctx = btn.get_style_context()
        has = ctx.has_class("flyme-task-active")
        if active and not has:
            ctx.add_class("flyme-task-active")
        elif has and not active:
            ctx.remove_class("flyme-task-active")

    def _on_clicked(self, _btn, xid):
        win = windows.by_xid(xid)
        if win is not None:
            self._toggle(win)

    def _on_press(self, _btn, ev, xid):
        win = windows.by_xid(xid)
        if win is None:
            return False
        if ev.button == 2:  # средняя кнопка — закрыть окно
            self._close(win)
            return True
        if ev.button == 3:
            self._menu(ev, xid)
            return True
        return False

    # ------------------------------------------------------------- действия

    @staticmethod
    def _toggle(win):
        try:
            now = Gtk.get_current_event_time()
            if win.is_minimized():
                win.unminimize(now)
                win.activate(now)
            elif win.is_active():
                win.minimize()
            else:
                win.activate(now)
        except Exception:
            pass

    @staticmethod
    def _close(win):
        try:
            win.close(Gtk.get_current_event_time())
        except Exception:
            pass

    def _toggle_xid(self, xid):
        win = windows.by_xid(xid)
        if win is not None:
            self._toggle(win)

    def _maximize_xid(self, xid):
        win = windows.by_xid(xid)
        if win is not None:
            try:
                win.maximize()
            except Exception:
                pass

    def _unmaximize_xid(self, xid):
        win = windows.by_xid(xid)
        if win is not None:
            try:
                win.unmaximize()
            except Exception:
                pass

    def _close_xid(self, xid):
        win = windows.by_xid(xid)
        if win is not None:
            self._close(win)

    def _menu(self, ev, xid):
        win = windows.by_xid(xid)
        if win is None:
            return True
        menu = Gtk.Menu()
        try:
            minimized = bool(win.is_minimized())
            maximized = bool(win.is_maximized())
        except Exception:
            minimized = maximized = False

        # замыкания держат только XID (см. комментарий в _make_button)
        items = []
        if minimized:
            items.append((_("Развернуть"), lambda: self._toggle_xid(xid)))
        else:
            items.append((_("Свернуть"), lambda: self._toggle_xid(xid)))
        if maximized:
            items.append((_("Восстановить размер"),
                          lambda: self._unmaximize_xid(xid)))
        else:
            items.append((_("Развернуть на весь экран"),
                          lambda: self._maximize_xid(xid)))
        items.append((_("Закрыть"), lambda: self._close_xid(xid)))

        for label, cb in items:
            mi = Gtk.MenuItem(label=label)
            mi.connect("activate", lambda _m, f=cb: f())
            menu.append(mi)
        menu.show_all()
        menu.connect("selection-done", lambda m: GLib.idle_add(m.destroy))
        menu.popup_at_pointer(ev)
        return True
